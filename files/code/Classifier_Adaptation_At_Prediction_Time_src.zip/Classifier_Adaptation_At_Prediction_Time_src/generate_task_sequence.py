#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

"""
**generate_task_sequence.py**

This script is used for generating realistic label sequences.
Call ; python generate_task_sequences.py -m [1] -y [2] -h [3] -l [4] -k [5]

  **Args**:
    |[1] (*str, optional*) : Choose method for sequence generation (KS, MDS or TXT). Defaults to KS.
    |[2] (*int, optional*) : Choose database (2010 or 2012). Defaults to 2010.
    |[3] (*int, optional*) : Choose height parameter. For TXT, it determines the maximum height to search for labels. For KS, it is used to build a refined Markov Chain (higher weights when staying in the same ancestor class). Defaults to 15.
    |[4] (*int, optional*) : Sequence length for KS/MDS. Defaults to 1500.
    |[5] (*int, optional*) : kNN Parameter for MDS. Defaults to 9.
    |[6] (*float, optional*) : Probability of a random jump in MDS and KS. Defaults to 0.
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import sys
import os
import argparse
import numpy as np
from modules.generate_task_sequence_MDS import random_walk_MDS, get_sequence_MDS
from modules.generate_task_sequence_KS import random_walk_grid, get_sequence_KS
from modules.generate_task_sequence_TXT import browse_text
from modules.utils import init_folder



def generate_seq(imported_coordinates, mode, n, tree_struct, k=8, hypernims=None, lambd=0, verbose=True):
    """
    Generate a random MDS or KS sequence.

    Args:
     * ``imported_coordinates`` (*str*): path to the file containing the pre-computed KS grid or MDS coordinates.
     * ``mode`` (*str*): KS or MDS.
     * ``n`` (*int*): length of the sequence.
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``k`` (*int, optional*): kNN parameter for MDS. Defaults to 35.
     * ``hypernims`` (*list, optional*): hypernims relations that can be used by KS to refine its random walk. Defaults to None.
     * ``lambd`` (*float*): probability of making a random jump.

    Returns:
     * ``labels`` (*list*): the generated sequence of labels.
    """

    if verbose:
        print "Imported Coordinates from ", imported_coordinates
    if mode == 'MDS':
        coords = np.loadtxt(imported_coordinates, dtype=np.float)
        return random_walk_MDS(n, coords, k, tree_struct, hypernims=hypernims, lambd=lambd)
    elif mode == 'KS':
        coords = np.loadtxt(imported_coordinates, dtype=np.int32)
        return random_walk_grid(n, coords, tree_struct, hypernims=hypernims, lambd=lambd)







if __name__ == '__main__':
    from extract_data import Node, extract_data
    import ConfigParser as cfg                         # 'configparser' for Python 3.0
    import pickle
    import time
    base_name = time.strftime("%Y-%m-%d_%H-%M")


    #=============================================================================================#
    #------------------------------------Initialization-------------------------------------------#
    #=============================================================================================#
    # ----------Main Parameters
    parser = argparse.ArgumentParser(description='Generate label sequence.')
    parser.add_argument("-m", "--method", dest="method", default="KS", type=str, help="Generation method (MDS, KS or TXT). Defaults to KS.")
    parser.add_argument("-y", "--year", dest="year", default=2010, type=int, help="Database (2010 or 2012). Defaults to 2010.")
    parser.add_argument("-he", "--height", dest="height", type=int, help="Height in the hierarchy tree.")
    parser.add_argument("-l", "--length", dest="length", default=1500, type=int, help="Sequence length.")
    parser.add_argument("-j", "--jump", dest="jump", default=0, type=float, help="Probability of a random jump for MDS and KS.")
    parser.add_argument("-k", dest="k", default=9, type=int, help="k parameter for KNN search in MDS.")

    args = parser.parse_args()
    method = args.method
    YEAR = args.year
    lambd = args.jump
    height = 15 if args.height is None and method == 'TXT' else (2 if args.height is None else args.height)
    seq_length = args.length
    k_neighb = args.k


    #--------- Set Pathes
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    section = str(YEAR)
    SAVEDATAFILE = config.get(section, 'preprocessedMetafile')

    folder_sequence = init_folder(os.path.join(config.get('Folders', 'output'), 'Task_Sequences', method, "ILSVRC%d"%YEAR))
    folder_plot = init_folder(os.path.join(config.get('Folders', 'output'), 'Data_Representations', method, "ILSVRC%d"%YEAR))



    #  --------- Preprocess Synsets
    arrangeddata = extract_data(YEAR)
    tree_struct = arrangeddata['tree']
    try:
        hypernims = arrangeddata['heights'][height][0]
    except KeyError:
        print "WARNING : File %s was not computed for height %d" %(SAVEDATAFILE, height)
        print "Plotting without hypernims relations \n"
        hypernims = None





    #=============================================================================================#
    #---------------------------------Sequence Generation-----------------------------------------#
    #=============================================================================================#



    #------------------------------------------------------Multi Dimensional Scaling
    if method == 'MDS':
        distances = arrangeddata['cost_matrix']
        imported_data = os.path.join(folder_plot, 'MDScoords.txt')
        output_walk = os.path.join(folder_sequence, 'MDSwalk_len%d_k%s_height%d_%s.txt'%(seq_length, k_neighb, height, base_name))

        _ = get_sequence_MDS(seq_length, k_neighb, distances, tree_struct, imported_coordinates=imported_data, height=height, hypernims=hypernims, lambd=lambd, output_walk=output_walk, output_coord_file=imported_data)


    #------------------------------------------------------Kernelized Sorting
    elif method == 'KS':
        distances = arrangeddata['cost_matrix']
        imported_data = os.path.join(folder_plot, 'KSgrid.txt')
        output_walk = os.path.join(folder_sequence, "KSwalk_len%d_height%d_%s.txt"%(seq_length, height, base_name))

        _ = get_sequence_KS(seq_length, distances, tree_struct, imported_coordinates=imported_data, height=height, hypernims=hypernims, lambd=lambd, output_walk=output_walk, output_grid_file=imported_data)


    #------------------------------------------------------Text Sequences
    elif method == 'TXT':
        sys.path.append(config.get('Lib', 'nltk'))
        synset_to_label = arrangeddata['synsets_to_ids']

        #Browsing the whole directory, by ascending file sizes
        path_to_txt = os.path.join('Data', 'Gutenberg_Books')
        path_to_tagged = init_folder(os.path.join(path_to_txt, 'Gutenberg_Tagged'))
        text_list = [x for x in os.listdir(path_to_txt) if x.endswith('.txt')]
        text_list = sorted(text_list, key=lambda t: os.stat(os.path.join(path_to_txt, t)).st_size)


        for text in text_list:
            print "\n---\n %s"%text
            name = text.rsplit('.', 1)[0]
            output_tagged = os.path.join(path_to_tagged, '%s.tag'%name)
            output_walk = os.path.join(folder_sequence, "TXT_%s_h%d_labels.txt"%(name, height))
            filename = output_tagged if os.path.isfile(output_tagged) else os.path.join(path_to_txt, text)
            browse_text(filename, height, synset_to_label, tree_struct, output_walk, output_tagged=output_tagged)


    #------------------------------------ Check
    else:
        print >> sys.stderr, 'Only modes KS, MDS and TXT are supported'
        raise SystemExit
