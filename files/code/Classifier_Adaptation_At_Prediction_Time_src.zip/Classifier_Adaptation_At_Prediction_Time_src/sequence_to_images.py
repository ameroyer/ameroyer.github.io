#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **sequence_to_images.py**

This script outputs a list of images corresponding to a sequence of labels for better vizualisation.
Call ; python sequence_to_images.py [1] [2] [3]

  **Args**:
    |[1] (*str, optional*) : Path to the label sequences text file. Defaults to Alice in Wonderland.
    |[2] (*int, optional*) : Max number of labels to browse. Defaults to 60.
    |[3] (*int, optional*) : Choose database (2010 or 2012). Defaults to 2010.

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import sys
import os
import pickle
import shutil
import random as rand
import ConfigParser as cfg
from modules.utils import init_folder
from modules.import_sequence import import_seq
from extract_data import Node, extract_data
from collections import defaultdict


def access_validation_data(path_to_valvectors, path_to_vallabels, imagename_fmt, withFeatures=False, filename=None):
    import numpy as np
    """
    Stores a structure mapping a classID to a list of the images (path) belonging to its class, and their features vector if required.

    Args:
     * ``path_to_valvectors`` (*str*): path to the array containing the features vector for the validation dataset.
     * ``path_to_vallabels`` (*str*): path to the list containing the corresponding ground truth labels.
     * ``imagename_fmt`` (*str*): format string such that imagename_fmt % i is the path to the i-th image in the validation dataset.
     * ``withFeatures`` (*bool, optional*): if True, images feature will be stored in the final structure too. Defaults to False.

    Returns:
     *  ``VALFEAT`` (*dict*): maps an imagenetId to a list of corresponding image pathes and features if required.
    """


    Xval = np.fromfile(path_to_valvectors, dtype=np.float32).reshape(-1,4096) if withFeatures else None #d=4096 features dimension
    Lval=np.loadtxt(path_to_vallabels, dtype=np.int32).T
    VALFEAT = {}
    for i, l in enumerate(Lval):
        img = imagename_fmt % (i+1)
        to_append = (Xval[i,:], img) if withFeatures else img
        VALFEAT[l].append(to_append)

    if filename is not None:
        print "Saving validation data to label correspondances:", filename
        init_folder(os.path.dirname(filename))
        with open(filename, "wb") as f:
            pickle.dump(VALFEAT, f)

    return VALFEAT



if __name__ == '__main__':
    try:
        seq_file = str(sys.argv[1])             #Path to label sequence text file
    except (IndexError, ValueError):
        seq_file = 'Data/ILSVRC2010/Sequences/TXT/SimpleTXTwalk11_uptoheight15.txt'

    try:
        n_total = int(sys.argv[2])           #Max number of labels to extract images for
    except (IndexError, ValueError):
        n_total = 60

    try:
        YEAR = int(sys.argv[3])                 #Choose Database for images
    except (IndexError, ValueError):
        YEAR = 2010


    #----------------------------- Importing hierarchy information
    section = str(YEAR)
    print "Processing Synsets"
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    PATH_TO_VALDATA = config.get(section, 'validationSet')
    PATH_TO_VALLABELS = config.get(section, 'validationLabels')
    path_to_validation_imgs = config.get(section, 'validationImages', raw = True)
    arrangeddata = extract_data(YEAR)
    tree_struct = arrangeddata['tree']
    synset_to_label = arrangeddata['synsets_to_ids']


    #---------------------------Get label sqauences
    labels = import_seq(seq_file)[:n_total]
    folder_output = init_folder(os.path.join('Outputs', 'Task_Sequences', 'with_Images', os.path.basename(seq_file).split('.')[0]))


    #----- Import ImageNet validation's dataset
    VALDATAFILE = os.path.join("Data", "class_to_validationIMG_%d.pkl" % YEAR)
    if not os.path.isfile(VALDATAFILE):
        label_to_validation = access_validation_data(PATH_TO_VALDATA, PATH_TO_VALLABELS, path_to_validation_imgs, filename=VALDATAFILE)
    else:
        print 'Load validation data correspondancies'
        with open(VALDATAFILE, 'rb') as pkl_file:
            label_to_validation = pickle.load(pkl_file)


    #---------------------------Create images
    print 'Browsing Labels'
    found = 1
    for label in labels:
        label += 1 #Imagenet ids start at 1
        if label > 1000:
            new_label = rand.choice(tree_struct[label].leaf_children)
        else:
            new_label = label
        classID = label_to_validation[new_label]
        image = rand.choice(classID)
        save_into = os.path.join(folder_output, "Img%d_%s_class%d.jpg"%(found, tree_struct[label].synset[0], label))
        shutil.copy(image, save_into)
        found += 1
