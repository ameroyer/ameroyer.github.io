#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **demo_classify.py**

This script runs the different adaptation methods on one sequence of the chosen database.
The final accuracies and predictions for each images are output in a html file having the following structure:

- ``Index.html``: Final accuracies (green line means best accuracy).
- ``Results.html``: Final classification guesses for each image.
    * a green label means a correct guess.
    * a green line means at least one of the combined algorithms guessed right, while the base classifier didn't.
    * a red line means the initial classifier guessed right and all the combined approaches guessed wrong.

**Note**: labels in the top-5 outputs columns are the top5 not ordered.



Default Call::

    python demo_classify.py -y [1] -s [2] -l [3] -j [4] -c [5]


**Args**:

* [1] (*int*): database (2010 or 2012).
* [2] (*str*): method for sequence generation (TXT, KS, or MDS).
* [3] (*int*): generated sequence length. Defaults to 150.
* [4] (*float*): probability of a random jump for MDS and KS. Defaults to 0.
* [5] (*str*): classifier to use. (`ccv` or `jsgd`). Defaults to ``ccv``.

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"



if __name__ == '__main__':
    import os
    import sys
    import numpy as np
    import bottleneck as bn
    import pickle
    import time
    import argparse
    from random import choice, shuffle
    import ConfigParser as cfg
    from extract_data import Node, extract_data
    from generate_task_sequence import generate_seq
    from modules.accuracy_measures import compute_accuracy, scores
    from modules.import_sequence import *
    from modules.utils import init_folder, Tee, html_header, html_footer, html_add_img, html_add_results
    from modules.init_forecasters import *
    base_name = time.strftime("%Y-%m-%d_%H-%M")



#============================================================== INIT PARAMETERS AND PATHES

    #----------Main Parameters
    parser = argparse.ArgumentParser(description='Demo for the classifier adaptation on one image sequence.')
    parser.add_argument("-y", "--year", type=int, default=2010, help="Database (2010 or 2012). Defaults to 2010")
    parser.add_argument("-s", "--set", default="TXT", help="Label Sequence database (TXT, KS or MDS)")
    parser.add_argument("-l", "--length", default=150, dest="seql", type=int,  help="Length of the sequences to use. Defaults to 150.")
    parser.add_argument("-j", "--jump", dest="lambd", default=0, type=float,  help="Random jump probability for the KS and MDS databases")
    parser.add_argument("-c", "--classifier", default="ccv", dest="classi", help="Classifier used (jsgd or ccv). Defauts to ccv.")
    parser.add_argument("-v", "--verbose", help="verbose output.", action="store_true")

    #Default
    args = parser.parse_args()
    YEAR = args.year
    using_set = args.set
    seq_length = args.seql
    classifier = args.classi
    verbose = args.verbose
    lambd = args.lambd


    if not YEAR in [2010, 2012]:
        print >> sys.stderr, "Only 2010 and 2012 supported at the moment"
        raise SystemExit


    if not using_set in ['KS', 'MDS', 'TXT', 'RND']:
        print >> sys.stderr, "Only KS, MDS, TXT and RND options supported"
        raise SystemExit



    #--------- Set configuration Pathes (training features + validation data)
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    section = str(YEAR)
    folder = init_folder(os.path.join(config.get('Folders', 'output'), 'ImageNet', 'ILSVRC%d'%YEAR, 'Demo'))
    num_classes = config.getint(section, 'n_classes')
    adaptation_schemes = load_forecasters(config)
    path_to_validation_imgs = config.get(section, 'validationImages', raw = True)

    #path to classifier params (jsgd) and precomputed scores (for validation dataset)
    precomputed_jsgd = config.get('classify', 'precomputed_scores', raw=True)%YEAR
    precomputed_ccv = config.get('classify', 'precomputed_ccv', raw=True)%YEAR
    true_labels = np.loadtxt(config.get(section, 'validationLabels'), dtype = np.int32).T - 1


    #  --------- Preprocess Synsets
    arrangeddata = extract_data(YEAR)
    tree_struct = arrangeddata['tree']
    hypernims = arrangeddata['heights'][4][0]
    del arrangeddata




#============================================================== INIT CLASSIFIER f

    # CCV
    if classifier == 'ccv':
        print 'Loading precomputed CCV scores'
        svm_scores = None
        try:
            with open(precomputed_ccv, 'r') as pkl_file:
                x = pickle.load(pkl_file)
                probs_scores = x['probs']
                del x
        except (OSError, KeyError):
            print 'File not found or Missing "probs" entry in dictionnary', precomputed_ccv
            print 'Exiting'
            raise SystemExit

    # JSGD
    elif classifier == 'jsgd':
        print 'Loading precomputed SVM-PLATT classifier scores'
        try:
            with open(precomputed_jsgd, 'r') as pkl_file:
                x = pickle.load(pkl_file)
                svm_scores = x['svm']
                probs_scores = x['probs']
        except (OSError, KeyError):
            print 'File not found or Missing "svm" or "prob" entry in dictionnary', precomputed_jsgd
            print 'Exiting'
            raise SystemExit



#============================================================== INIT LABEL SEQUENCES

    print 'Importing %s sequence(s)' %using_set
    # Import random pre-computed TXT sequence
    if using_set == 'TXT':
        txt_path = config.get('classify', 'path_to_txt', raw=True)%YEAR
        flist = [x for x in os.listdir(txt_path) if (x.endswith('.txt') and os.stat(os.path.join(txt_path, x)).st_size != 0)]
        name = choice(flist)
        (indices, labels) = import_seq_features(os.path.join(txt_path, name), tree_struct, true_labels)
        (indices, labels) = (indices[:seq_length], labels[:seq_length])
        name = name.split('.')[0]


    # Generate Random MDS or KS sequence
    elif using_set == 'MDS' or using_set == 'KS':
        k = config.getint('classify', 'mds_knn')
        imported = config.get('classify', 'path_to_mds' if using_set == 'MDS' else 'path_to_ks', raw=True) % YEAR
        name = using_set + '_seq_' + base_name
        (indices, labels) = import_seq_features_aux(generate_seq(imported, using_set, seq_length, tree_struct, k=k, hypernims=hypernims, lambd=lambd, verbose=verbose), true_labels)


    # Rqndom sequences
    elif using_set == 'RND':
        indices = range(probs_scores.shape[1]) if classifier == 'ccv' else range(svm_scores.shape[1])
        c = list(zip(indices, true_labels))
        shuffle(c)
        name = 'Random_data_' + base_name
        (indices, labels) = zip(*(c[:seq_length]))


    #Init result HTML file
    folder = init_folder(os.path.join(folder, name))
    title_html = 'Results on %s sequence - length %d - Database %d - %s Classifier'%(using_set, seq_length, YEAR, classifier)
    restr = html_header(title_html) + """<table border="1">
<tr>
<td>Query</td>
<td>Top-1 Outputs</td>
<td>Top-5 Outputs</td>
</tr>"""



#============================================================== START CLASSIFICATION


    #----------------------------------------Define which combined algorithms to use
    if svm_scores is not None:
        methods = ['Base(SVM)', 'Base(Probs)']
    else:
        methods = ['Base(Probs)']
    forecasters, loaded_forecasters = init_forecaster_module(num_classes, adaptation_schemes)
    methods.extend(loaded_forecasters)
    print 'Using adaptation methods :', methods
    accuracies1 = np.zeros((len(methods), 1))
    accuracies5 = np.zeros((len(methods), 1))

    print 'Doing sequence %s. length %d' %(name, len(labels))
    start_index = 0

    #----------- Basic SVM accuracy
    if svm_scores is not None:
        accuracies1[0] = compute_accuracy(svm_scores[:, indices].T, labels, topk=1, verbose=verbose)
        accuracies5[0] = compute_accuracy(svm_scores[:, indices].T, labels, topk=5, verbose=verbose)
        start_index += 1


    #----------- Basic SVM accuracy after Platt scaling or ccv probs
    basic_probs = probs_scores[:, indices]
    if 'Base(Probs)' in methods:
        accuracies1[start_index] = compute_accuracy(basic_probs.T, labels, topk = 1, verbose = verbose)
        accuracies5[start_index] = compute_accuracy(basic_probs.T, labels, topk = 5, verbose = verbose)
        start_index += 1



    #--------------------------- Forecasters
    reinit_forecasters(forecasters)
    array_scores = init_array_scores(basic_probs, forecasters)

    #Browse label sequentially
    #Apply each forecaster + print result in HTML file
    for i, label in enumerate(labels):
        guesses = []
        guesses5 = []
        if svm_scores is not None:
            guesses.append(np.argmax(svm_scores[:, indices[i]]))
            guesses5.append(bn.argpartsort(-svm_scores[:,indices[i]], n=5)[:5])
        guesses.append(np.argmax(basic_probs[:, i]))
        guesses5.append(bn.argpartsort(-basic_probs[:,i], n=5)[:5])

        for j, mat in enumerate(array_scores):
            f = forecasters[methods[j + start_index]]
            _, predictions = f.predictAndUpdate(label, mat[:,i])
            mat[:,i] = predictions
            guesses.append(np.argmax(predictions))
            guesses5.append(bn.argpartsort(-predictions, n=5)[:5])

        path_to_img = path_to_validation_imgs%(indices[i]+1)
        restr += html_add_img(path_to_img, label, tree_struct, methods, guesses, guesses5, start_index)

    #Compute FinalAccuracies for forecasters
    for j, mat in enumerate(array_scores):
        accuracies1[start_index  + j] = compute_accuracy(mat.T, labels, topk = 1, verbose = verbose)
        accuracies5[start_index  + j] = compute_accuracy(mat.T, labels, topk = 5, verbose = verbose)




    #--------------------------------- Print Mean Accuracies + HTML outputs
    print '\n--------Final Results :', using_set, seq_length
    print '->Top-1 accuracies'
    for i, line in enumerate(accuracies1):
        print "_ %s : %.5f " %(methods[i], line[0])

    print '\n\n->Top-5 accuracies'
    for i, line in enumerate(accuracies5):
        print "_ %s : %.5f " %(methods[i], line[0])


    #HTML OUTPUT
    print '\nFinal Output in', folder + 'index.html'
    fhtml = open(os.path.join(folder, 'results.html'), 'w')
    fhtml.write(restr + html_footer())
    fhtml.close()

    fhtml = open(os.path.join(folder, 'index.html'), 'w')
    fhtml.write(html_add_results(title_html, methods, accuracies1[:,0], accuracies5[:,0]))
    fhtml.close()
