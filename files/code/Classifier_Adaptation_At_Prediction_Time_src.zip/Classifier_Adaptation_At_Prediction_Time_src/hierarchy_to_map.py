#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **hierarchy_to_map.py**

This script is used for plotting 2D representation of the ImageNet hierarchy. See :ref:`data_representation <data-label>` module for more information on the actual function calls.
Default Call::

    python hierarchy_to_map.py [1] [2] -c [3] [options]

**Args**:

* [1] (*int*) : ILSVRC year (2010 or 2012).
* [2] (*str*) : sets method for plot generation (KS or MDS).
* [options] (*optional*):
    * -h, --help: display help.
    * -c [3] (*int*): sets height parameter for color clustering. Defaults to 4.

**Notes**:
Results are output in the [Output]/Data_Representations directory.

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


if __name__ == '__main__':
    import sys
    import time
    import os
    import argparse
    import ConfigParser as cfg                         # 'configparser' for Python 3.0
    import numpy as np
    from extract_data import Node, extract_data
    from modules.utils import init_folder
    from modules.data_representation import mds_mapping, mds_representation, kernelized_sorting_map, array_to_plot
    base_name = time.strftime("%Y-%m-%d_%H-%M")




    #---------------- Configure
    parser = argparse.ArgumentParser(description='Computes coordinates for MDS and KS.')
    parser.add_argument("year", type = int, help="Database (2010 or 2012)")
    parser.add_argument("set", help="Projection Method (KS or MDS)")
    parser.add_argument("-l", "--level", dest="height", default = 4, type = int, help="Height for color clutering defaults to 4.")
    args = parser.parse_args()

    year = args.year
    method = args.set
    height = args.height

    config = cfg.ConfigParser()
    main_dir = os.path.dirname(os.path.realpath(__file__))
    config.read(os.path.join(main_dir, 'configuration.ini'))
    folder = os.path.join(config.get('Folders', 'output'),  'Data_Representations/')
    output_path = init_folder(os.path.join(folder, method, 'ILSVRC%d'%year))
    output_file = os.path.join(output_path, '%sMap_height%d_%s'%(method, height, base_name))


    #  --------- Preprocess Synsets
    arrangeddata = extract_data(year)
    tree_struct = arrangeddata['tree']
    dists = arrangeddata['cost_matrix'].astype(float)
    classes = range(dists.shape[0])
    try:
        hypernims = arrangeddata['heights'][height][0]
    except KeyError:
        print "WARNING : File %s was not computed for height %d" %(SAVEDATAFILE, height)
        print "Plotting without hypernims relations \n"
        hypernims = None



    #--------------------------Multi dimensional scaling
    if method == 'MDS':
        imported_coordinates = os.path.join(output_path, 'MDScoords.txt')

        # Generate or load existing point coordinates
        if not os.path.isfile(imported_coordinates):
            coords = mds_mapping(dists, imported_coordinates)
        else:
            print "Imported Coordinates from ", imported_coordinates
            coords = np.loadtxt(imported_coordinates, dtype = np.float)

        # Plot
        mds_representation(classes, tree_struct, coords, showlabels=True, showall=False, hypernims=hypernims, filename='%s.pdf'%output_file)




    #----------------------Kernalized Sorting
    elif method == 'KS':
        imported_coordinates = os.path.join(output_path, 'KSgrid.txt')

        # Generate or load existing KS grid
        if not os.path.isfile(imported_coordinates):
            patching = kernelized_sorting_map(dists, apply_kernel=False, outputfile=imported_coordinates)
        else :
            print "Imported Coordinates from ", imported_coordinates
            patching = np.loadtxt(imported_coordinates, dtype = np.int32)

        # Plot
        array_to_plot(patching, tree_struct, showlabels=True, showall=False, hypernims=hypernims, filename=output_file + ".pdf")


    #------------------Unrecognized mode
    else:
        print >> sys.stderr, 'Only modes KS and MDS are supported'
        raise SystemExit
