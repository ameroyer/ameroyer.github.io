#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************


""" **utils.py**

Various auxiliary functions.
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import numpy as np
from errno import EEXIST


def init_folder(dirname):
    """
    Create the folder for a file if not already existing.

    **Args**:
        | path(*str*): path to the file whose folder we want to create.
    """
    import os
    try:
        os.makedirs(dirname)
        print 'Creating folder', dirname
    except OSError as e:
        if e.errno != EEXIST:
            raise e
    return dirname



class Tee(object):
    """
    Tee object for log file
    """
    def __init__(self, *files):
        self.files = files

    def write(self, obj):
        for f in self.files:
            f.write(obj)


def text_titles():
    """
    Outputs the list of all text titles from the gutenberg book folder
    """
    import os
    import re
    path_to_txt = 'Data/Gutenberg_Books/'
    text_list = os.listdir(path_to_txt)
    convert = lambda text: int(text) if text.isdigit() else text
    alphanum_key = lambda key: [convert(c) for c in re.split('([0-9]+)', key)]
    text_list = sorted(text_list, key = alphanum_key)
    c = 0
    for text in text_list:
        if text.endswith('.txt'):
            c += 1
            number = int(text.split('.')[0])
            f = open(path_to_txt + text)
            print number, ':', f.readline().upper()
            f.close()
    print c, 'texts'


def html_header(title):
    """
    Header for HTML output in demo_classify
    """
    
    return """<!doctype html>
<html lang="en">
<style media="screen" type="text/css">
i{
color: #21610B;
font-weight: bold;
font-style: normal
}

body { text-align:center;}

.center {text-align:center;}
table{
    border-collapse: collapse;
    border-spacing: 0;
    border:1px solid #000000;
	margin:0 auto;
    padding:0px;
}
td{
	vertical-align:middle;
	border:1px solid #000000;
	border-width:0px 1px 1px 0px;
	text-align:left;
	padding:10px;
	font-size:15px;
	font-family:Arial;
	font-weight:normal;
	color:#02446b;
}
tr{
	background-color:#f2f2f2;
}
tr:first-child td{
	background-color:#74aacc;
	text-align:center;
	font-size:19px;
	font-family:Trebuchet MS;
	font-weight:bold;
	color:#ffffff;
}

a{
font-weight:bold;
font-variant:small-caps;
color:#1A72AD;
word-spacing:6pt;
font-size:17px;
font-family:arial, helvetica, sans-serif;
}
</style>
<head>
  <meta charset="utf-8">
  <title>%s</title>
</head>
<body>
<h1>%s</h1>
"""%(title, title)



def html_add_img(path_to_img, label, tree_struct, methods, guesses, guesses5, start_index):
    """
    Add a line in HTML output for demo_classify
    """
    right_f = label in guesses[:start_index]
    right_g = label in guesses[start_index:]
    good = (not right_f) and right_g
    bad = right_f and (not right_g)

    if good:
        start = """<tr style="background-color: #D0F5A9;">"""
    elif bad:
        start = """<tr style="background-color: #F5A9A9;">"""
    else:
        start = """<tr>"""
    img = start + """<td class="center"><img src ='%s' width='200px'></img>
<br>%d - %s</br /></td>
<td>%s</ul></td>
<td style="white-space: nowrap">%s</ul></td>
</tr>
"""

    lis = """<ul>"""
    lis5 = """<ul>"""
    for k, (m,g,I) in enumerate(zip(methods, guesses, guesses5)):
        if k == start_index or k == start_index + 2 or k == start_index + 5:
            lis += """</ul><ul>"""
            lis5 += """</ul><ul>"""

        if g == label:
            lis += """<li><b>%s</b> predicts <i>%d - %s</i></li>""" %(m, g+1, tree_struct[g+1].synset)
        else:
            lis += """<li><b>%s</b> predicts %d - %s</li>""" %(m, g+1, tree_struct[g+1].synset)
        top5 = ""
        for i in I:
            if i == label:
                top5 += """<span title="%s"><i>%d</i></span> """%(tree_struct[i + 1].synset, i+1)
            else:
                top5 += """<span title="%s">%d</span> """%(tree_struct[i + 1].synset, i+1)
        lis5 += """<li><b>%s</b> predicts %s</li>""" %(m, top5)

    return img%(path_to_img, label + 1, str(tree_struct[label + 1].synset), lis, lis5)


def html_add_results(title, methods, accuracies1, accuracies5):
    """
    Add results page for HTML output in demo_classify
    """
    header = html_header(title) + """<table border="1">
<tr>
<td>Query</td>
<td>Top-1 Accuracies</td>
<td>Top-5 Accuracies</td>
</tr>"""

    b1 = np.argmax(accuracies1)
    b5 = np.argmax(accuracies5)
    for i, (m, acc1, acc5) in enumerate(zip(methods, accuracies1, accuracies5)):
        header += """<tr><td>%s</td>""" %m
        if i == b1:
            header += """<td><i>%.5f</i></td>""" %acc1
        else:
            header += """<td>%.5f</td>""" %acc1

        if i == b5:
            header += """<td><i>%.5f</i></td>""" %acc5
        else:
            header += """<td>%.5f</td>""" %acc5
    header += """</tr></table>
<a href = 'results.html' target="_blank">Detailled classification results</a>
</body>
</html>
"""
    return header






def html_footer():
    """
    HTML closing tags for demo_classify
    """
    return """</table>
</body>
</html>
"""
