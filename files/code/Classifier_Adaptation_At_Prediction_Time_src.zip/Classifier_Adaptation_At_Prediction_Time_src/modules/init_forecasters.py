#!/usr/bin/python
# -*- coding: utf-8 -*-


#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************


""" **init_forecasters.py**

Initializes the different adaptation methods based on the configuration file options.
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


from forecaster import *


def load_forecasters(config):
    """
    Parse the configuration file and retrieve the adaption classifiers to be used.

    Args:
    * ``config`` (*configparser*): opened configuration file.
    """
    forecasters = []
    if config.getboolean('algos', 'adapt'):
        forecasters.append('Multinomial')

    if config.getboolean('algos', 'reinforced_adapt'):
        forecasters.append('Reinforced_Multinomial')

    if config.getboolean('algos', 'self_guided_unsupervised_adapt'):
        forecasters.append('Self_Guided_Unsupervised_Multinomial')

    if config.getboolean('algos', 'dynamic_adapt'):
        forecasters.append('Dynamic_Multinomial')

    if config.getboolean('algos', 'dynamic_reinforced_adapt'):
        forecasters.append('Dynamic_Reinforced_Multinomial')

    if config.getboolean('algos', 'dynamic_self_guided_unsupervised_adapt'):
        forecasters.append('Dynamic_Self_Guided_Unsupervised_Multinomial')

    return forecasters



def init_forecaster_module(num_classes, forecasters):
    """
    Initializes the adaptation classifiers.

    Args:

    * ``num_classes`` (*int*): number of classes in the task.
    * ``forecasters`` (*list*): list of names of the classifiers to use.
    """

    predictors = {}
    ordered_found = []

    for f in forecasters:
        if f == 'Multinomial':
            pred = Multinomial_Forecaster(num_classes)

        elif f == 'Reinforced_Multinomial':
            pred = Reinforced_Multinomial_Forecaster(num_classes)

        elif f == 'Self_Guided_Unsupervised_Multinomial':
            pred = Self_Guided_Unsupervised_Multinomial_Forecaster(num_classes)

        elif f== 'Dynamic_Multinomial':
            pred = Dynamic_Multinomial_Forecaster(num_classes)

        elif f== 'Dynamic_Reinforced_Multinomial':
            pred = Dynamic_Reinforced_Multinomial_Forecaster(num_classes)
        elif f== 'Dynamic_Self_Guided_Unsupervised_Multinomial':
            pred = Dynamic_Self_Guided_Unsupervised_Multinomial_Forecaster(num_classes)

        else:
            continue

        predictors[f] = pred
        ordered_found.append(f)

    return predictors, ordered_found



def init_array_scores(basic_probs, forecasters):
    """
    Initialize an array to store the accuracies for each classifier.
    """
    return [np.copy(basic_probs) for f in forecasters]




def reinit_forecasters(forecasters):
    """
    Reinitializes all the classifiers
    """
    for f in forecasters.values():
        f.reinit()
