#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************


""" **svm_to_prob.py**

This module contains functions to transform an array of SVM scores to an array of probabilities (Platt scaling).

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"

if __name__ == '__main__':
    import matplotlib
    matplotlib.use('Agg') #NoDisplay
import numpy as np
import random as rand







def use_platt_scaling(c_numb, scores, valLabels, outputfile = None):
    """
    Computes Platt parameters (A,B) for each OVR classifiers.     

    Args:    
     * ``c_numb`` (*int*): number of classifiers.
     * ``scores`` (*ndarray*): scores for the n features in the validation dataset (c_numxn array)
     * ``valLabels`` (*list*): ground truth labels for the corresponding features.
     * ``outputfile`` (*str, optional*): path to the file the parameters will be written in. Defaults to None.

    Returns:    
     * ``params`` (*list*): the Platt parameters.
    
    """
    from platt import SigmoidTrain
    save_params = [[] for j in xrange(c_numb)]
    if outputfile != None:
        f = open(outputfile, 'w')

    print "%d classifiers" %c_numb
    for classifier in xrange(c_numb):
        #Preprocess valLabels for an OVR approach: binary (-1, +1) representation
        valLabelsOVR = [0] * len(valLabels)
        
        for i, labelT in enumerate(valLabels):
            if labelT != classifier:
                valLabelsOVR[i] = -1
            else:
                valLabelsOVR[i] = +1
                
        #Compute the sigmoid
        [A, B] = SigmoidTrain(scores[classifier, :], valLabelsOVR)
        save_params[classifier] = [A, B]
        print "Classifier %d; A = %.3f, B = %.3f" %(classifier, A, B)        
        if outputfile is not None:
            f.write("%d %.8f %.8f\n" %(classifier, A, B))
    
    if outputfile is not None:
        f.close()
        
    return save_params





def multi_SigmoidPredict(all_scores, params):
    """
    Given SVM scores and Platt parameters, this function outputs the transformed probabilistic scores.     

    Args:    
     * ``all_scores`` (*ndarray*): scores for the n features in the validation dataset (kxn array).
     * ``params`` (*ndaray*): Platt parameters (A,B) for the k OVR classifiers

    Returns:    
     * ``probs`` (*ndarray*): probability array such that probs[label, feature] = P(label | feature).
    
    """
    probs = np.zeros(all_scores.shape)
    step = (all_scores.shape[1])/10 #For printing progress
    c = 0
    for feature in xrange(all_scores.shape[1]):
        scores = all_scores[:, feature]
        total = 0.
        for i, (s, (A,B)) in enumerate(zip(scores, params)):
            fApB = A*s + B
            if fApB < 0: 
                gi = 1.0 / (1 + np.exp(A*s + B))
            else:
                gi = np.exp(-fApB)/(1.0 + np.exp(-fApB))
            probs[i, feature] = gi
            total += gi
        probs[:, feature] = probs[:, feature] / total
        c += 1
        if c == step:
            print 'SigmoidPredict; Done %d/%d' %(feature+1, all_scores.shape[1])
            c = 0
    return probs



def import_platt_params(filename, num_class = 1000):
    """
    Import Platt parameters from a text file.

    Args:     
     * ``filename`` (*str*): path to the file containing the parameters.
     * ``num_classes`` (*int, optional*): Number of OVR classifiers. Defaults to 1000.

    Returns:    
     * ``save_params`` (*ndarray*): Platt parameters.
    
    """
    f = open(filename, 'r')
    save_params = [[] for j in xrange(num_class)]
    for i, l in enumerate(f):
        [cl, A, B] = l.split()
        save_params[i] = [ float(A), float(B)]
    f.close()
    return save_params
