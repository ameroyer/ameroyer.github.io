#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **accuracy_measures.py**

Various accuracy measures for evaluation purpose.
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import numpy as np
import bottleneck as bn

def confusion_matrix(found_labels, right_labels, num_classes):
    """
    This function computes a confusion matrix given the retrieved and ground truth labels (note that these labels should start at index 0).

    Args:
     * ``found_labels`` (*list*): labels output by a classifier for a sequence of samples.
     * ``right_labels`` (*list*): corresponding ground truth labels.
     * ``num_classes`` (*int*): number of classes.

    Returns:
     * ``confusion`` (*ndarray*): the corresponding unnormalized confusion matrix.

    """
    confusion = np.zeros((num_classes, num_classes), np.float32)
    for ytheo, yexp in zip(right_labels, found_labels):
        confusion[ytheo, yexp] += 1
    return confusion







def confusions_matrix(found_labels, right_labels, heights):
    """
    This function computes a confusion matrix at different nodes-levels of the Imagenet hierarchy, given the retrieved and ground truth leaf-labels (note that these labels should start at index 0).

    Args:
     * ``found_labels`` (*list*): (leaf) labels output by the classifier.
     * ``right_labels`` (*list*): corresponding ground truth labels.
     * ``heights`` (*dict*): for each height, contains a tuple of the form ``[hypernims, hyponims, number of ancestors]`` (see ``extract_data.py``).
      * ``hypernims: x -> (ancestor_id, id)`` maps a label to the ImageNet ID of its ancestor at the considered height, and a integer id associated to this ancestor among all nodes at this height.
      * ``hyponims: x -> children_ids``: converse relation.
      * ``n_acc``: number of nodes at the considered height.


    Returns:
     * ``confusions`` (*dict*): dict mapping a height to the corresponding confusion matrix.

    """
    confusions = {i: np.zeros((h[2], h[2]), np.int32) for i, h in heights.items()}

    for ytheo, yexp in zip(right_labels, found_labels):
        for i, h in heights.iteritems():
            hypernims = h[0]
            father_ytheo = (hypernims[ytheo+1])[1]
            father_yexp = (hypernims[yexp+1])[1]
            confusions[i][father_ytheo, father_yexp] += 1
    return confusions




def scores(X, W):
    """
    This function computes the SVM scores matrix given a set of features and a set of weights parameters for a multi-class SVM classifier (one-versus-rest).

    Args:
     * ``X`` (*ndarray*): each line contains a d-dimensional feature for one of the `n` samples (`n`x`d` array).
     * ``W`` (*ndarray*): each line contains the weights for one classifier for each one of the `k` class in the task (`k`x`d` array).

    Returns:
     * ``scores`` (*ndarray*): each column contains the scores for a sample for each SVM (kxn array).
     * ``found_labels`` (*list*): labels output by the classifier for each feature.

    """
    X1 = np.hstack([X, np.ones((X.shape[0], 1), dtype = np.float32)])
    scores = np.dot(W, X1.T)
    found_labels = np.argmax(scores, axis = 0)
    return scores, found_labels







def compute_accuracy(scores, y, topk=5, verbose = True):
    """
    Computes a topk-accuracy for a multi-class classifier.

    Args:
     * ``scores`` (*ndarray*): each column contains the scores for one of the `n` samples for each one of the `d` classes (`d`x`n` array).
     * ``y`` (*list*): list of ground truth labels for the features. Starting Index 0.
     * ``topk`` (*int, optional*): topk parameter for the accuracy. Defaults to 5.

    Returns:
     * ``accuracy`` (*float*): the topk-accuracy for the given classifier.
    """

    import time
    start_time = time.time()
    if topk == 1:
        hits = (np.argmax(scores, axis = 1) == y)
    else:
        I = bn.argpartsort(scores, n=scores.shape[1]-topk, axis=1)[:,-topk:] # largest k indices
        hits = (I==np.reshape(y, (-1,1))).any(axis=1)
    if verbose:
        print "eval: %f secs" % (time.time()-start_time)
    return np.mean(hits)




def compute_hierarchy_cost(scores, y, dist_mat, max_height, topk=5):
    """
    Computes a hierarchical topk-accuracy for a multi-class classifier.

    Args:

    * ``scores`` (*ndarray*): each column contains the scores for one feature for all classifiers (kxn array).
    * ``y`` (*list*): list of ground truth labels for the features.
    * ``dist_mat`` (*ndarray*): Imagenet hierarchical cost matrix (least common ancestor distance).
    * ``topk`` (*int, optional*): topk parameter for the accuracy. Defaults to 5.

    Returns:

    * ``accuracy`` (*float*): the topk-accuracy for the given classifier.

    """

    import time
    import bottleneck as bn
    start_time = time.time()
    if topk == 1:
        I = np.argmax(scores, axis = 1)
    else:
        I = bn.argpartsort(scores, n=scores.shape[1]-topk, axis=1)[:,-topk:] # largest k indices

    sc = 0.
    for line, gt in zip(I, y):
        if isinstance(line, int):
            sc += dist_mat[gt, line] / max_height
        else:
            dists = [dist_mat[gt, fl] for fl in line]
            sc += min(dists) / max_height
    print "eval: %f secs" % (time.time()-start_time)
    return 1 - sc / len(y)






def subtree_accuracy(heights, tree_struct, labels, found_labels, right_labels, filename):
    """
    This function computes accuracies for each class agains all subtrees containing this class (i.e., number of object of true category y that are correclty classified as y, or correctly classified in the subtree of height 1 of y, ... etc).

    Args:
     * ``heights`` (*dict*): contains tuples of the form ``[hypernims, hyponims, number of ancestors]`` for each height (see ``extract_data.py``).
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``found_labels`` (*list*): labels output by the classifier.
     * ``right_labels`` (*list*): corresponding ground truth labels.
     * ``filename`` (*str*): path to the file the results will be written in.

    """
    f = open(filename, 'w')

    #Mapping each ground truth label to its predicted labels
    misclassifications = [[] for i in labels]
    for y, ybar in zip(right_labels, found_labels):
        misclassifications[y].append(ybar)

    #Compute accuracy for each leaf-label, and each subtree height
    means = [[h, 0] for h in heights]
    for l in labels:
        for h, [hypernims, _, n_ances] in heights.items():
            ancestor = hypernims[l+1][0]
            childclass = tree_struct[ancestor].leaf_children
            right = 0

            #Compute the number of found_labels that are in the correct subtree
            for ybar in misclassifications[l]:
                if ybar + 1 in childclass:
                    right += 1

            #Compute accuracy
            if len(misclassifications[l]) != 0:
                accuracy = float(right)/len(misclassifications[l])
                means[h][1] += accuracy
            else:
                accuracy = -1

            #Write result in file
            f.write("%s | %d | %d | %s | %.5f\n" %(tree_struct[l+1].synset[0], l+1, h, tree_struct[ancestor].synset[0], accuracy))


    #Write mean accuracies for each height
    for m in means:
        mean = float(m[1])/len(labels)
        f.write("%s | %d | %d | %s | %.5f\n" %("mean accuracy per task", -1, m[0], "", mean))
        print "Mean Accuracy per task of height %d; accuracy of %.5f" %(m[0], mean)

    f.close()
