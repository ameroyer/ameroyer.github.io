#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **data_representation.py**

.. _data-label:

This module contains various functions for plotting data representations.
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import matplotlib
matplotlib.use('Agg', warn=False) #NoDisplay
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.colors as colors
import matplotlib.cm as cm
import numpy as np
import random as rand
import time
import sys
import os
from utils import init_folder



def pick_color():
    """
    Returns a random rgb color (components in range [0,1]).

    Returns:

    * ``rgb`` (*tuple*): a rgb color.
    """
    [r,g,b] = [rand.random() for i in range(3)]
    return (r,g,b)






#===========================================================================================#
#--------------------------- Multi Dimension Scaling Method --------------------------------#
#===========================================================================================#

def mds_mapping(adist, filename=None):
    """
    This function computes a 2D data-representation from a distance matrix, using the implementation of metric Multi Dimension Scaling method of skit-learn.

    Args:
     * ``adist`` (*ndarray*): distance matrix. (kxk array).
     * ``filename`` (*str, optional*): path to the file the result will be written in. Defaults to None.


    Returns:
     * ``coords`` (*ndarray*): array containing the data points' coordinates after the projection. (kx2 array).
    """

    from sklearn import manifold
    amax = np.amax(adist)
    adist /= amax

    print "Call to sklearn's MDS ..."
    start_time = time.time()
    mds = manifold.MDS(metric = True, n_components=2, dissimilarity="precomputed", random_state=6)
    results = mds.fit(adist)
    print "sklearn returned; %.3f s" %(time.time() - start_time)

    coords = results.embedding_
    if filename is not None:
        init_folder(os.path.dirname(filename))
        np.savetxt(filename, coords, fmt='%.8f')

    return coords






def mds_representation(classes, tree_struct, coords, showlabels=True, showall=False, hypernims=None, filename=None):
    """
    This function outputs a 2D data-representation from a set of points (in practice, obtained through MDS), with cluster-coloring and class labelling, using the matplotlib library.

    Args:
     * ``classes`` (*list*): subset of data points/classes to plot.
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``coords`` (*ndarray*): array containing the data points coordinates. (kx2 array).
     * ``showlabels`` (*bool, optional*): when ``True``, labels will be parially displayed on the plot, for readibility. Defaults to True.
     * ``showall`` (*bool, optional*): when ``True``, each point's label will be shown (not recommended for large databases). If false, only one label in each cluster will be shown. Defaults to False.
     * ``hypernims`` (*list, optional*) : list mapping a leaf-label to one of its ancestors for a given height. These relations will be used for cluster-coloring. Defaults to None.
     * ``filename`` (*str, optional*): path to the PDF file the result will be written in. Defaults to None.

    """

    print "Starting Data Plotting with MDS; %d data points" %(len(classes))
    fig = plt.figure(figsize=(15,15))
    plt.subplots_adjust(bottom = 0.1)
    colours = {}
    if hypernims is None:
            plt.scatter(coords[:, 0], coords[:, 1], marker = 'o')

    # Hierarchical Coloring + Legend
    for cl, x, y in zip(classes, coords[:, 0], coords[:, 1]):

        #Adding colors to clusters
        if hypernims is not None:
            ancestor = hypernims[cl+1][0]
            ancestor_name = tree_struct[ancestor].synset[0]
            try:
                c = colours[ancestor]
                plt.scatter(x,y, marker = 'o', color = c)
            except KeyError:
                #if no colour has been generated for this cluster yet
                c = pick_color()
                colours[ancestor] = c
                plt.scatter(x,y, marker = 'o', color = c, label = ancestor_name)
                #Labelling a point in each cluster
                if showlabels and (not showall):
                    plt.annotate(
                    ancestor_name,
                    xy = (x, y), xytext = (-20, 20),
                    textcoords = 'offset points', ha = 'right', va = 'bottom',
                    bbox = dict(boxstyle = 'round,pad=0.5', fc = 'yellow', alpha = 0.5),
                    arrowprops = dict(arrowstyle = '->', connectionstyle = 'arc3,rad=0'))

        #Labeling all points if requested
        if showlabels and showall:
            plt.annotate(
                tree_struct[cl+1].synset[0],
                xy = (x, y), xytext = (-20, 20),
                textcoords = 'offset points', ha = 'right', va = 'bottom',
                bbox = dict(boxstyle = 'round,pad=0.5', fc = 'yellow', alpha = 0.5),
                arrowprops = dict(arrowstyle = '->', connectionstyle = 'arc3,rad=0'))


    #Legend
    ax = plt.gca()
    handles, labels = ax.get_legend_handles_labels()
    lgd = plt.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5,-0.1))

    if filename is not None:
        print "Saving File in", filename
        init_folder(os.path.dirname(filename))
        with PdfPages(filename) as pp:
            fig.savefig(pp, dpi = 10, format='pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
    #plt.show()











#======================================================================================#
#--------------------------- Kernalized Sorting Method --------------------------------#
#======================================================================================#



def kernelized_sorting_map(distances, apply_kernel=False, gridlength=40, gridheight=25, outputfile=None):
    """
    This function computes a 2D data-grid representation from a distance matrix, using the Kernalized Sorting method.

    Args:
     * ``distances`` (*ndarray*): distance matrix. (kxk array).
     * ``apply_kernel`` (*bool, optional*): when ``True``, KS will use the input matrix as a list of vector describing the data points (should be ``False`` when the input is already a distance matrix). Defaults to False.
     * ``gridlength`` (*int, optional*): length of the resulting grid. Defaults to 40.
     * ``gridheight`` (*int, optional*): height of the resulting grid. Defaults to 25.
     * ``output_file`` (*str, optional*): path to the file the result will be written in. Defaults to None.

    Returns:
     * ``patching`` (*ndarray*): array containing the final grid. (note that gridlength x gridheight should be greater than k).
    """

    print "Call to KS_Python"
    import ConfigParser as cfg
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    sys.path.append(config.get('Lib', 'hungarian'))
    from kernelizedsorting.kernelized_sorting import KS

    #Calling KS Python
    ino = gridheight
    jno = gridlength
    griddata = np.zeros((2,ino*jno))
    griddata[0,] = np.kron(range(1,ino+1),np.ones((1,jno)))
    griddata[1,] = np.tile(range(1,jno+1),(1,ino))

    PI = KS(distances, griddata.T, apply_kernel = apply_kernel)
    i_sorting = PI.argmax(axis=1)
    patching = np.reshape(i_sorting, (ino, jno))

    if outputfile is not None:
        print "Saving KS grid in", outputfile
        init_folder(os.path.dirname(outputfile))
        np.savetxt(outputfile, patching)

    return patching







def array_to_plot(a, tree_struct, showlabels=True, showall=True, hypernims=None, filename=None, cellsize=30):
    """
    This function outputs  2D data-representation of points in a grid structure (in practice obtained through Kernelized Sorting), with cluster-coloring and class labelling.

    Args:
     * ``a`` (*ndarray*): the grid containing the labels.
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``showlabels`` (*bool, optional*): when ``True``, some labels will be displayed on the plot, for easier recognition. Defaults to True.
     * ``showall`` (*bool, optional*): when ``True``, each point's label will be shown (not recommended for large databases). If false, only one label in each cluster will be shown. Defaults to False.
     * ``hypernims`` (*list, optional*): list mapping a leaf-label to one of its ancestors for a given height. These relations will be used for cluster-coloring. Defaults to None.
     * ``filename`` (*str, optional*): path to the PDF file the result will be written in. Defaults to None.
     * ``cellsize`` (*int, optional*): cellsize of the figure. Defaults to 30.
    """

    # Define figure
    xlim = a.shape[1] * cellsize
    ylim = a.shape[0] * cellsize

    # Custom parameters for readability
    if showlabels:
        fig = plt.figure(figsize=(100,80))
        epsilon = 1
        dpi = 120
        fontsize = 32
    else:
        fig = plt.figure()
        dpi = 5
        fontsize = 'normal'

    # Remove ticks
    ax = fig.gca()
    ax.set_xticks(np.arange(0,xlim,cellsize))
    ax.set_yticks(np.arange(0,ylim,cellsize))
    ax.axes.xaxis.set_ticklabels([])
    ax.axes.yaxis.set_ticklabels([])
    ax.axis([-2*cellsize, xlim + 2*cellsize, cellsize, ylim])
    plt.grid()

    #Plotting each point
    colours = {}
    y = ylim - cellsize/2
    for i in range(a.shape[0]):
        x = cellsize/2
        for j in range(a.shape[1]):
            classId = a[i, j]
            class_name = tree_struct[classId+1].synset[0]

            # Adding colors to clusters
            if hypernims is not None:
                ancestor = hypernims[classId+1][0]
                ancestor_name = tree_struct[ancestor].synset[0]
                try:
                    c = colours[ancestor]
                    ax.add_patch(matplotlib.patches.Rectangle((x-cellsize/2,y-cellsize/2), cellsize, cellsize, color=c))
                except KeyError:
                    # if no colour has been generated for this cluster yet
                    c = pick_color()
                    colours[ancestor] = c
                    ax.add_patch(matplotlib.patches.Rectangle((x-cellsize/2,y-cellsize/2), cellsize, cellsize, color=c))
                    ax.scatter(x,y, marker = 'o', color = c, label = ancestor_name)
                    # Labeling the first found point in the cluster
                    if showlabels and not showall:
                        ax.annotate(
                        ancestor_name,
                        xy = (x, y), xytext = (-5, epsilon*30),
                        textcoords = 'offset points', ha = 'center', va = 'bottom',
                        bbox = dict(boxstyle = 'round,pad=0.5', fc = 'yellow', alpha = 0.75),
                        size = fontsize)
                        epsilon = - epsilon
            else:
                ax.scatter(x,y, marker = 'o')

            # Labeling all points if requested
            if showlabels and showall:
                ax.annotate(
                    class_name,
                    xy = (x, y), xytext = (-5, epsilon*30),
                    textcoords = 'offset points', ha = 'center', va = 'bottom',
                    bbox = dict(boxstyle = 'round,pad=0.5', fc = 'yellow', alpha = 0.75),
                    size = fontsize)
                epsilon = -epsilon

            x += cellsize
        y -= cellsize

    #Add legend
    if not showall:
        handles, labels = ax.get_legend_handles_labels()
        lgd = ax.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5,-0.1),prop={'size':fontsize+12})
    if filename is not None:
        print "Saving to file", filename
        init_folder(os.path.dirname(filename))
        pp = PdfPages(filename)
        if not showall:
            fig.savefig(pp, dpi = dpi, format = 'pdf', bbox_extra_artists=(lgd,), bbox_inches='tight')
        else:
            fig.savefig(pp, dpi = dpi, format = 'pdf')
        pp.close()
    #plt.show()







#===========================================================================================#
#------------------------------------ Miscellaneaous ---------------------------------------#
#===========================================================================================#
def generate_dot_file(tree_struct, output, dpi=630, probs=None, chose=None):
    """
    This function outputs a dot (and generated pdf) file representing the hierarchy tree of the database.

    Args:
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``output`` (*str*): base name for the output files (dot and pdf)
     * ``dpi`` (*int, optional*): figure resolution. Defaults to 630.
     * ``probs`` (*list, optional*): list of probabilities assocaited to each leaf labels; used for coloring the nodes. Defaults to None.
     * ``chose`` (*list, optional*): list of labels (not necessarily leaves) that will be in a different colors as the others. Defaults to None.

    """

    #Header
    init_folder(os.path.dirname(output))
    f = open(output, 'w')
    f.write('digraph \"tree_representation\" {\n')
    f.write('\tgraph [dpi = %d];\n' %dpi)
    f.write('\tedge [dir=none];\n')
    leaf = '\tnode [shape=box, height = 1., style=filled, fillcolor=cadetblue2];\n'
    ancestor = '\tnode [shape=ellipse, height = 1., fillcolor=white];'
    relations = ''

    #Browse nodes
    for n in tree_struct.values():
        index = n.imagenetId
        for c in n.children:
            relations += '\tn%d -> n%d;\n' %(index, c)

        #Node style
        if probs is not None and chose is not None and index <= 1000:
            p = probs[index - 1]
            label = "label=\"" + n.synset[0] +  ("\" fillcolor=\"%.3f %.3f %.3f\"" %(0, p, 1 - p))
            if 1-p < 0.45:
                label += 'fontcolor=\"white\"'
        elif chose is not None and index in chose:
            label = "label=\"" + n.synset[0] + "\" fillcolor=\"cadetblue\""

        else:
            label = "label=\"" + n.synset[0] + "\""

        #Add node to leaves or ancestors
        toadd = '\tn%d [%s];\n' %(index, label)
        if n.isLeaf:
            leaf += toadd
        else:
            ancestor += toadd

    #Footer
    f.write(leaf + ancestor + relations)
    f.write('}\n')
    f.close()
    print 'Generating dot and pdf in', output
    os.system("dot -T pdf " + output + ' > ' + output.rsplit('.',1)[0] + '.pdf')
