#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **generate_task_sequence_TXT.py**

This script is used for generating labels sequence from TXT and uses NLTK.
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import numpy as np
import pickle
from random import shuffle

import nltk
from nltk.tag import pos_tag
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer


def browse_text(filename, height, synset_to_label, tree_struct, output_walk, hypernims=None, output_tagged=None):
    """
    This function returns a sequence of labels computed with a random walk on a MDS 2D representation of the data.

    Args:
     * ``filename`` (*str*): path to the file to be read. If .tag file, the function assumes the text was already tagged.
     * ``height`` (*int*): Maximum height of labels to look for.
     * ``synset_to_label`` (*dict*): maps a word to the corresponding imagenetidD(see ``extract_data.py``).
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``output_walk`` (*str*): path to the file the sequence will be written in.
     * ``hypernims`` (*list, optional*) : list mapping a leaf-label to one of its ancestors for a given height. These relations will be used to display the ancestors classes. Defaults to None.
     * ``output_tagged`` (*str, optional*): path to the pickle file the tagged text will be written in. Defaults to None.

    Returns:
     * ``label_list`` (*list*): the sequence of labels found in the text.
    """

    #---------- Tagging Text
    print "Tagging Text"

    #Pre-computed Tagging
    if filename.endswith(".tag"):
        #If already precomputed
        with open(filename, 'rb') as tag_file:
            print "Loading from tag file"
            lines = tag_file.read().split('\n')
            tobrowse = []
            for l in lines:
                nn = l.split(' ')
                if len(nn) == 2:
                    tobrowse.append(nn)

    #Tagging with default NLTK tagger
    else:
        f = open(filename)
        codec = 'utf-8'
        tobrowse = pos_tag(word_tokenize(f.read().decode(codec, errors = 'ignore').lower().replace('-', ' '))) #replace '-' by ' ' for composed word (eg daisy-chain, waistcoast-pocket)
        f.close()
        if output_tagged != None:
            print "Saving tagged text in", output_tagged
            with open(output_tagged, 'w') as f:
                for (w,t) in tobrowse:
                    try:
                        f.write(w + ' ' + t + '\n')
                    except UnicodeEncodeError:
                        continue


    #--------- Browsing Text
    print "Browsing Text"
    wnl = WordNetLemmatizer()
    result = open(output_walk, 'w')

    i = 0
    while i < len(tobrowse):
        (word, tag) = tobrowse[i]
        #If noun in plural form, lemmatize using the wordnet module
        if tag == 'NNS':
            word = wnl.lemmatize(word, 'n')

        #If the word is a noun and belongs to one of the synsets we are interested in
        if (tag == 'NN' or tag == 'NNS') and word in synset_to_label:
            l = synset_to_label[word]
            #If several synsets match, pick one at random
            if len(l) > 1:
                shuffle(l)


            #Browse all potential matching synsets
            found = False
            for (seq, label) in l:
                if tree_struct[label].min_height > height: #Limiting the height of retrieved classes
                    continue

                #If the matching synset has only one word
                if seq == '':
                    found = True
                    skip = 1
                    break

                #If the synset is in several words (e.g. Egyptian cat)
                # test that it matches the context of the word
                else:
                    (index, tomatch) = seq
                    carret = i
                    try:
                        for u in tomatch:
                            if u == tobrowse[carret-index][0]:
                                carret += 1
                                if carret-index >= len(tobrowse):
                                    raise KeyError
                            else:
                                raise KeyError
                        found = True
                        word = ' '.join(tomatch) #Only for printing
                        skip = len(tomatch)
                        break
                    except KeyError:
                        continue


            #If a matching synset was found, add it to the sequence
            if found == False:
                i += 1
                continue
            else:
                i += skip
                node = tree_struct[label]
                class_synset = node.synset
                label_height = node.min_height
                if hypernims == None:
                    result.write("%d | %s | %s | %d \n" %(label, word, class_synset, label_height))
                else: #If hypernims, write ancestor node
                    ancestorID = hypernims[node.leaf_children[0]][0]
                    ancestorname = tree_struct[ancestorID].synset[0]
                    result.write("%d | %s | %d | %d | %s | %d \n" %(label, word, label_height , ancestorID, ancestorname, height))
        else:
            i += 1
    result.close()
    print "Output saved in", output_walk
