#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **compute_imagenet_hierarchy.py**

This module contains every function related to processing
on the FULL ImageNet hierarchy. When called as main, it
computes the hierarchy structure as well as the hierarchical misclassification cost as described on the ILSVRC webpage.

Default Call::

    python compute_imagenet_hierarchy.py [year]
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import time
import numpy as np
from lxml import etree
from utils import init_folder
from multiprocessing import Process, cpu_count, Queue



class ImageNet_Node():
    """
       Node element of the ImageNet structure.
    """

    def __init__(self, wordNetId, parent, synset, isLeaf, isRoot,
                 depth, children, height):
        """
        ImageNet_Node initialization.

        Args:
         * ``wordNetId`` (*int*): wordNet Id of the node.
         * ``parent`` (*ImageNet_Node list*): list of the node's parent(s).
         * ``synset`` (*str list*): wordNet description of the node.
         * ``isLeaf`` (*bool*): indicates wether the node is a leaf or not.
         * ``isRoot`` (*bool*): indicates wether the node is the root or not.
         * ``depth`` (*int*): node's depth (shortest path to the root).
         * ``children`` (*ImageNet_Node list*): list of the node's children.
         * ``height`` (*int*): wordNet height (longest path to a leaf in the full ImageNet hierarchy) of the node.

        """
        self.wordNetId = wordNetId
        self.parent = parent
        self.children = children
        self.synset = synset
        self.isLeaf = isLeaf
        self.isRoot = isRoot
        self.height = height
        self.depth = depth
        self.ancestors = []


    def get_descendants(self, descendant):
        """
        Retrieves all descendants of a node.

        Args:
         * ``descendants`` (*list*): accumulator list.
        """
        for c in self.children:
            descendant.append(c)
            c.get_descendants(descendant)


    def get_ancestors(self, ancestors):
        """
        Retrieves all ancestors of a node.

        Args:
         * ``ancestors`` (*list*): accumulator list.
        """
        for p in self.parent:
            ancestors.append(p)
            p.get_ancestors(ancestors)




def process_imagenet_node(nodes, parent_node, parent_xml_elem, depth=1):
    """
    Recursively computes an internal representation of an ImageNet subtree.

    Args:
     * ``nodes`` (*(str -> ImageNet_Node) dict*): current dictionnary of the nodes in the hierarchy.
     * ``parent_node`` (*ImageNet_Node*): root of the subtree to process.
     * ``parent_xml_elem`` (*lxml.Element*): xml element corresponding to parent node.
     * ``depth`` (*int*): current depth.

    Returns:
     * ``height`` (*int*): wordNet height (longest path to a leaf in the full ImageNet hierarchy) of parent_node.
    """
    height = 0
    children = []
    for k in parent_xml_elem.xpath('./synset'):
        wnid = k.get('wnid')
        synset = k.get('words').split(', ')
        isLeaf = (len(k.xpath('synset')) == 0)

        try:
            node = nodes[wnid]
            node.parent.append(parent_node)
            node.depth = min(node.depth, depth)
        except KeyError:
            nodes[wnid] = ImageNet_Node(wnid, [parent_node], synset, isLeaf, False, depth, [], 0)
        children.append(nodes[wnid])

        if isLeaf:
            height = max(height, 1)
        else:
            height_through_k = process_imagenet_node(nodes, nodes[wnid], k, depth + 1) + 1
            height = max(height, height_through_k)

    parent_node.height = height
    parent_node.children = children

    return height





def process_full_imagenet_hierarchy(xml_path):
    """
    Computes an internal representation of the ImageNet hierarchy from a XML file.

    Args:
     * ``xml_path`` (*str*): path to the source xml file.

    Returns:
     * ``nodes`` (*(str -> ImageNet_Node) dict*): dictionnary (keys: wordNetId) containing all nodes of the hierarchy.
    """
    with open(xml_path, 'rt') as f:
        # Parse XML file
        tree = etree.parse(f)
        root = tree.xpath('./synset')[0]
        nodes = {} #Dict of all nodes

        # Add root node
        root_node = ImageNet_Node('n00001740', [], ['entity'],
                                  False, True, 0, [], 0)
        nodes['n00001740'] = root_node

        # Compute hierarchy structure + nodes height
        root_height = process_imagenet_node(nodes, root_node, root)
        root_node.height = root_height

        return nodes, root_node




def print_hierarchy(nodes, src, f, indent = 0):
    """
    Writes an indented text representation of the processed hierarchy.

    Args:
     * ``nodes`` (*(str -> ImageNet_Node) dict*): dictionnary (keys: wordNetId) containing all nodes of the hierarchy.

     * ``src`` (*ImageNet_Node*): root of the subtree currently being printed.
     * ``f`` (*file*): output file.
     * ``indent`` (*int, optional*): current indentation level.
    """

    if src.isLeaf:
        f.write("%sLead Node %s: %s. Height: %s. Depth: %s\n"%('\t'*indent, src.wordNetId, ', '.join(src.synset), src.height, src.depth))
    elif src.isRoot:
        f.write("%sRoot Node %s: %s. Height: %s. Depth: %s\n"%('\t'*indent, src.wordNetId, ', '.join(src.synset), src.height, src.depth))
    else:
        f.write("%sNode %s: %s. Height: %s. Depth: %s\n"%('\t'*indent, src.wordNetId, ', '.join(src.synset), src.height, src.depth))

    for c in src.children:
        print_hierarchy(nodes, c, f, indent + 1)




def get_deepest(nodeA, nodeB):
    """
    Given two nodes, returns the one deepest in the hierarchy.

    Args:
     * ``nodeA`` (*ImageNet_Node*)
     * ``nodeB`` (*ImageNet_Node*)
    """

    if nodeA.depth < nodeB.depth:
        return nodeB
    else:
        return nodeA



def find_lca(nodeA, nodeB):
    """
    Returns the lowest (ie deepest) common ancestor of two nodes.

    Args:
     * ``nodeA`` (*ImageNet_Node*)
     * ``nodeB`` (*ImageNet_Node*)
    """

    if nodeA == nodeB:
        return nodeA
    elif nodeA.isRoot:
        return nodeA
    elif nodeB.isRoot:
        return nodeB
    else:
        ancestorsA = nodeA.ancestors
        ancestorsB = nodeB.ancestors
        ca = list(set(ancestorsA) & set(ancestorsB))
        lca = max(ca, key= lambda x: x.depth)
        #print "LCA %s x %s : %s (depth %d)" %(nodeA.synset[0], nodeB.synset[0], lca.synset[0], lca.depth)
        return lca


def run_search_lca(thread_id, main_nodes, nodes, queue):
    """
    Run the search of LCA for a subset of the nodes
    (threaded execution).

    Args:
     * ``thread_id`` (*int*): number to characterize the thread.
     * ``main_nodes`` (*int list*): list of the nodes the thread will compute on (more precisely the thread will compute the lca(x,y) for x in main_nodes and y in nodes[main_nodes:]).
     * ``nodes`` (*ImageNet_Node*): list of all nodes.
     * ``queue`` (*Queue*): queue to store the result of the thread execution.
    """
    print "Thread %d - start." %thread_id
    for n in main_nodes:
        start = time.time()
        nodeA = nodes[n]
        for j in xrange(n+1, len(nodes)):
            nodeB = nodes[j]
            lca = find_lca(nodeA, nodeB)
            cost = lca.height
            queue.put((n, j, cost))
        end = time.time()
        print "Done Node %d in %s s (Thread %d)" %(n, end-start, thread_id)
    queue.close()
    queue.join_thread()
    print "Thread %d - done." %thread_id



def get_misclassification_costs(subset, xml_path, core = 2, write_hierarchy = None):
    """
    Returns a matrix containing the misclassification costs for all the pair of
    nodes in the set (subset x subset). The misclassification cost d(x,y) is
    defined as the height (i.e longest path to a leaf in the full ImageNet
    hierarchy) of the lowest common ancestor of x and y.

    Args:
     * ``subset`` (*str list*): a list of wordnet Ids for which to compute the matrix.
     * ``xml_path`` (*str*): path to the xml file containing the full hierarchy.
     * ``core`` (*int, optional*): number of cores to use. Min1. Defaults to 2.
     * ``write_hierarchy`` (*str*): path in which to write the hierarchy structure,
      for debugging purpose. Defaults to None.
    """
    cpuc = cpu_count()
    if core < 1:
        print "Warning: Core Number too low. Setting it to 1"
        core = 1
    elif core > cpuc:
        print "Warning: Core Number exceeds cpu cores. Setting it to %d" %cpuc
        core = cpuc

    # Compute hierarchy structure
    print "Compute Hierarchy"
    nodes, root_node = process_full_imagenet_hierarchy(xml_path)
    for n in nodes.values():
        ancestors = []
        n.get_ancestors(ancestors)
        n.ancestors = ancestors

    if write_hierarchy:
        with open(write_hierarchy, 'w') as f:
            print_hierarchy(nodes, root_node, f)

    # Compute LCAs and hierarchical cost
    print "Compute LCAs"
    cost_matrix = np.zeros((len(subset), len(subset)))
    processi = []
    resqueue = Queue()

    for i in xrange(core):
        index_list = range(i, len(subset), core)
        t = Process(target = run_search_lca,
                    args=(i, index_list, [nodes[x] for x in subset], resqueue,))
        processi.append(t)
        t.start()

    #Retrieve all coefficients sent to the queue
    for coeff in xrange(len(subset)*(len(subset) - 1)/2):
        (a, b, cost) = resqueue.get()
        cost_matrix[a, b] = cost
        cost_matrix[b, a] = cost

    #Join
    print 'Waiting for Threads'
    for i, t in enumerate(processi):
        t.join()
        print 'joined thread %d'%i

    return cost_matrix






if __name__ == "__main__":
    import sys
    from modules.utils import Tee
    import ConfigParser as cfg                   # 'configparser' for Python 3+
    import argparse

    # Parse
    parser = argparse.ArgumentParser(description='Extracts full ImageNet hierarchy infornation.')
    parser.add_argument("year", type = int, help="Database (2010 or 2012)")
    args = parser.parse_args()
    year = args.year

    # Read Config file
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    section = str(year)
    output_folder = init_folder(config.get('Folders', 'output'))

    # Write hierarchy
    print 'Load meta file'
    xml_path = config.get('ImageNet', 'hierarchy')
    write_hierarchy = os.path.join(output_folder, 'imagenet_hierarchy.txt')
    metafile = config.get(section, 'metafile')
    max_class = config.getint(section, 'n_classes')

    # Get ILSVRC classes wordNet Ids
    from scipy.io import loadmat, savemat
    meta = loadmat(metafile)
    M = meta['synsets']
    wordNetIds = []
    D = {}
    synsets = {}
    for m in M:
        if m[0][0][0][0] <= max_class:
            D[m[0][1][0]] = m[0][0][0][0] - 1
            wordNetIds.append(m[0][1][0])
        synsets[m[0][1][0]] = m[0][2][0]
    wordNetIds.sorted(wordNetIds, key= lambda x: D[x])

    #Compute cost matrix
    cost_matrix = get_misclassification_costs(wordNetIds, xml_path, core = 3, write_hierarchy=write_hierarchy)

    #Write Output
    np.savetxt(os.path.join(output_folder, 'cost_matrix_2012.txt'), cost_matrix, fmt="%d")
    with open(os.path.join(output_folder, 'wordnetIds_2012.txt'), 'w') as f:
        for wid in wordNetIds:
            f.write(str(wid) + ' - '  + synsets[wid] + '\n')
