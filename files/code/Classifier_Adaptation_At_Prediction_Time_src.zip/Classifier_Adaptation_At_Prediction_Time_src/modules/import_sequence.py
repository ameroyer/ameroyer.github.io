#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **import_sequence.py**

Auxiliary functions for processing a label sequences from a file
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import sys
import numpy as np
import numpy.random as rand
import pickle
import ConfigParser as cfg            # 'configparser' for Python 3+
import time
from extract_data import Node
base_name = time.strftime("%Y-%m-%d_%H-%M")
import bottleneck as bn
import os




#================================================================================================#
#============================ Importing label sequences =========================================#
#================================================================================================#


def import_seq(filename, onlyLeaf=True, tree_struct=None):
    """
    This function returns a sequence of labels from a file (where the file contains the index of the labels).

    Args:
     * ``filename`` (*str*): path to the file containing the sequence.
     * ``onlyLeaf`` (*bool, optional*): if True, then if the sequence contains an ancestor node label, we randomly sample one its leaf children instead.
     * ``tree_struct`` (*dict, optional*): contains the nodes of the hierarchy tree (see ``extract_data.Node``). Should not be ``None`` when onlyleaf is True. Defaults to None.

    Returns:
     * ``labels`` (*list*): a sequence of labels.

    """
    import random
    f = open(filename, 'r')
    labels = []
    for l in f:
        label = int((l.replace(" ", "").split('|'))[0])
        if onlyLeaf and tree_struct is not None:
            candidates = tree_struct[label].leaf_children
            label = random.choice(candidates)
        labels.append(label - 1)
    f.close()
    return labels




def import_seq_features(filename, tree_struct, valLabels):
    """
    Given a file containing a sequence of labels (not restricted to leaves), this function returns a sequence of indices of validation images that matches the labels.

    Args:
     * ``filename`` (*str*): path to the file containing the labels sequence.
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``valLabels`` (*list*): ground truth labels from an image set.

    Returns:
     * ``indices`` (*list*): list of indices of images from the original set that matches the order of the labels sequence.
     * ``labels`` (*list*): the corresponding sequence of labels.

    """
    import random
    f = open(filename, 'r')
    labels = []
    indices = []
    for l in f:
        #Choose a corresponding leaf label
        label = int((l.replace(" ", "").split('|'))[0])
        if label > 1000:
            candidates = tree_struct[label].leaf_children
            label = random.choice(candidates)

        #Random image
        index = random.choice(np.argwhere(valLabels == label-1))[0]
        labels.append(label - 1)
        indices.append(index)
    f.close()
    return indices, np.array(labels)



def import_seq_features_aux(f, valLabels):
    """
    Given a sequence of LEAF labels , this function returns a sequence of indices of validation images that matches the labels.

    Args:
     * ``filename`` (*str*): path to the file containing the labels sequence.
     * ``valLabels`` (*list*): ground truth labels from an image set.

    Returns:
     * ``indices`` (*list*): list of indices of images from the original set that matches the order of the labels sequence.
     * ``labels`` (*list*): the corresponding sequence of labels.

    """
    import random
    labels = []
    indices = []
    for label in f:
        index = random.choice(np.argwhere(valLabels == label))[0]
        labels.append(label)
        indices.append(index)
    return indices, np.array(labels)




def import_seq_name(filename, synset_to_label, tree_struct, onlyLeaf = True):

    """
    Same as import seq but expects the file to contain a list of labels names identifiers instead of label integer ids.
    """
    import random
    f = open(filename, 'r')
    lines = f.read().split('\n')
    labels = []
    for line in lines:
        tobrowse = line.split()
        for word in tobrowse:
            l = synset_to_label[word]
            #If several synsets match, pick one at random
            if len(l) > 1:
                rand.shuffle(l)
            #Browse all potential matching synsets
            found = False
            for (seq, label) in l:
                #If the matching synset has only one word
                if seq == '':
                    found = True
                    skip = 1
                    break
                #If the synset is in several words (e.g. Egyptian cat)
                # test that it matches the context of the word
                else:
                    (index, tomatch) = seq
                    carret = 0
                    try:
                        for u in tomatch:
                            if u == tobrowse[carret-index][0]:
                                carret += 1
                                if carret-index >= len(tobrowse):
                                    raise KeyError
                            else:
                                raise KeyError
                            found = True
                            skip = len(tomatch)
                            break
                    except KeyError:
                        continue
        if found == False:
            continue
        else:
            if onlyLeaf and tree_struct is not None:
                candidates = tree_struct[label].leaf_children
                label = random.choice(candidates)
            labels.append(label - 1)
    f.close()
    return labels
