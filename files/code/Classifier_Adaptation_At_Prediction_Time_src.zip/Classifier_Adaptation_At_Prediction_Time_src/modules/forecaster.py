#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **forecaster.py**

This module contains the different adaptation classifiers (named Forecaster here).
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import numpy as np
import bottleneck as bn
from extract_data import Node
import random




#================================================================================================#
#===================================== Main Class ===============================================#
#================================================================================================#

class Forecaster(object):
    """
    Forecaster parent class.
    """

    def __init__(self, weights):
        """
        Object initialization.

        Args:
         * ``weights`` (*ndarray*): inital parameters of the forecaster.
        """

        self.weights = weights                  #Parameters of the model
        self.time_t = 0                         #current time in the sequence
        self.acc1 = 0.                          #Top 1-accuracy up to time t (unnormalized)
        self.acc5 = 0.                          #Top 5-accuracy up to time t (unnormalized)
        self.perplexity = 0.                    #Log Perplexity up to time t (unnormalized)
        self.cum_perplexities = []              #cumulative log perplexities from 0 to t





    def getPrediction(self, input_x, true_label):
        """
        Forecaster's prediction.

        Args:
         * ``input_x`` (*list*): the input vector parameters used to do the prediction, if appliable.
         * ``true_label`` (*int*): the ground truth label.

        **Returns**:
         * ``predicted_label`` (*int*): the forecaster's prediction.
         * ``scores`` (*list*): The scores for each label computed by the forecaster.

        """
        #Predicting next label
        input_x = np.reshape(input_x, (-1, 1))
        scores = np.dot(self.weights, input_x)
        predicted_label = random.choice(np.argwhere(scores == np.amax(scores))[:, 0])

        #Computing top1 and top5 accuracies
        I = bn.argpartsort(-scores.T, n=5)[:, :5]
        self.acc1 += float(true_label == predicted_label)
        self.acc5 += float(true_label in I)
        self.time_t += 1

        return predicted_label, scores




    def getAccuracies(self):
        """
        return accuraciy measures for current time. Note that those are computed for Prediction only (ie, consider only the label predicted before multiplying by the classifier score)

        Returns:
         * ``acc1`` (*float*): top1-accuracy .
         * ``acc5`` (*float*): top5-accuracy.
         * ``perplexity`` (*float*): perplexity.
        """
        return (self.acc1 / self.time_t), (self.acc5 / self.time_t), (self.perplexity / self.time_t)


    def getWeights(self):
        """
        returns the weights parameters for the current time.

        Returns:
         * ``weights`` (*ndarray*): weights.
        """
        return self.weights


    def getCumulativePerplexities(self):
        """
        Return cumulative perplexities up to current time.

        Returns:
         * ``cum_perplexiities`` (*ndarray*): cumulative perplexities.
        """
        return self.cum_perplexities


    def predictAndUpdate(self, label, svm_scores): #to override
        """
        Given the true label and the svm scores, this functions outputs the predicted label and the prediction vector of the **combined** forecaster.

        Args:
         * ``label`` (*int*): the ground truth label.
         * ``svm_scores`` (*list*): output of the initial pre-trained classifier.
        """
        pass


    def reinit(self): #to override
        """
        Reinitialize the forecaster
        """
        self.time_t = 0
        self.acc1 = 0
        self.acc5 = 0
        self.perplexity = 0
        self.cum_perplexities = []
        self.weights = None




















#================================================================================================#
#================================ Simple Adaptation Classifier =======================================#
#================================================================================================#

class Multinomial_Forecaster(Forecaster):
    """Multinomial Forecaster (Simple adpatation classifier).
       Updates its parameters with the words counts.
    """


    def __init__(self, k, update=1.0, epsilon=0.5):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.5
        """
        Forecaster.__init__(self, np.zeros(k) + epsilon)
        self.k = k
        self.update = update
        self.epsilon = epsilon




    def reinit(self): #@Override
        """
        Reinitialize the forecaster
        """
        Forecaster.reinit(self)
        self.weights = np.zeros(self.k) + self.epsilon




    def getPrediction(self, true_label): #@Override
        """
        Forecaster's prediction.
        No input_x parameter (the prediction model only uses its weights to predict).

        Args:
         * ``true_label`` (*int*): the ground truth label.

        **Returns**:
         * ``predicted_label`` (*int*): the multinomial model's prediction.
         * ``scores`` (*list*): The scores for each label computed by the forecaster.

        """

        self.time_t += 1

        #Predicting next label
        scores = self.weights
        predicted_label = random.choice(np.argwhere(scores == np.amax(scores))[:, 0])

        #Computing top1 and top5 accuracies
        I = bn.argpartsort(-scores.T, n=5)[:5]
        self.acc1 += float(true_label == predicted_label)
        self.acc5 += float(true_label in I)

        #Perplexity
        self.perplexity -= np.log(scores[true_label] / np.sum(scores))
        self.cum_perplexities.append(self.perplexity / self.time_t)

        #Return
        return predicted_label, scores



    def predictAndUpdate(self, true_label, svm_scores): #@Override
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence.
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): /!\ : contrary to the other cases, returns the most frequent label, as given by the current estimate of the distribution pi.
         * ``prediction_scores`` (*list*): final adaptation classifier (pretrained+adaptation score for each label).
        """

        #Prediction by exploiting the weights
        predicted_label, prediction_scores = self.getPrediction(true_label)
        prediction_scores = np.ravel(prediction_scores / np.sum(prediction_scores))

        #Update
        self.weights[true_label] += self.update

        return predicted_label, prediction_scores * svm_scores





class Self_Guided_Unsupervised_Multinomial_Forecaster(Multinomial_Forecaster):
    """Unsupervised Multinomial Forecaster.
       Updates its parameters with the word counts.
       Do not use additionnal information on the correct label (unsupervised setting).
    """

    def __init__(self, k, update=1.0, epsilon=0.5):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.5.
        """
        Multinomial_Forecaster.__init__(self, k, update, epsilon)


    def reinit(self):
        """
        Reinitialize the forecaster
        """
        Multinomial_Forecaster.reinit(self)



    def predictAndUpdate(self, true_label, svm_scores):
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence. (Will only be used to compute accuracies not for the update).
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): the label predicted by the combined pretrained+adaptation.
         * ``prediction_scores`` (*list*): final adaptation classifier (pretrained+adaptation score for each label).

        """

        #Prediction by exploiting the weights + svm scores
        _, forecaster_scores = Multinomial_Forecaster.getPrediction(self, true_label)
        forecaster_scores = np.ravel(forecaster_scores / np.sum(forecaster_scores))

        #Combine with classifier probabilities
        combined_scores = svm_scores * forecaster_scores
        predicted_label = random.choice(np.argwhere(combined_scores == np.amax(combined_scores))[:, 0])

        #Update
        total = np.sum(combined_scores)
        self.weights += combined_scores / total

        return predicted_label, combined_scores






class Reinforced_Multinomial_Forecaster(Multinomial_Forecaster):
    """Unsupervised Multinomial Forecaster.
       Updates its parameters with the word counts and adds a penalty to a wrongly predicted label.
       Only uses the information of wheter the predicted label is correct or not (semi-supervised setting).
    """


    def __init__(self, k, update=1.0, epsilon=0.5):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.05.
        """
        Multinomial_Forecaster.__init__(self, k, update, epsilon)



    def reinit(self):
        """
        Reinitialize the forecaster
        """
        Multinomial_Forecaster.reinit(self)



    def predictAndUpdate(self,true_label, svm_scores): #@Override
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence.
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): the label predicted by the combined pretrained+adaptation.
         * ``prediction_scores`` (*list*): final adaptation classifier (pretrained+adaptation score for each label).
        """

        #Prediction by exploiting the weights + svm scores
        _, forecaster_scores = Multinomial_Forecaster.getPrediction(self, true_label)
        forecaster_scores = np.ravel(forecaster_scores / np.sum(forecaster_scores))

        #Combine with SVM-Platt probabilistic scores
        combined_scores = svm_scores * forecaster_scores
        predicted_label = random.choice(np.argwhere(combined_scores == np.amax(combined_scores))[:, 0])

        #Update
        if predicted_label == true_label:
            self.weights[predicted_label] += self.update
        else:
            self.weights += 1.0 / (self.k - 1)
            self.weights[predicted_label] -= 1.0 / (self.k - 1)

        return predicted_label, combined_scores



#================================================================================================#
#================================ Dynamic Adaptation Classifier =======================================#
#================================================================================================#

class Dynamic_Multinomial_Forecaster(Multinomial_Forecaster):
    """Dynamic Multinomial Forecaster (Adaptation classifier with dynamic strategy).
       Add a sliding window
    """


    def __init__(self, k, update=1.0, epsilon=0.5, sliding_window=100):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.5
        """
        Multinomial_Forecaster.__init__(self, k, update, epsilon)
        self.past = [] #store past updates contained in the sliding window
        self.sliding_window = sliding_window




    def reinit(self): #@Override
        """
        Reinitialize the forecaster
        """
        Multinomial_Forecaster.reinit(self)
        self.past = []


    def update_past(self, current_update):
        """
        Update the sliding window by removing older updates
        """
        if len(self.past) >= self.sliding_window:
            oldest = self.past.pop(0)
            self.weights -= oldest
        self.past.append(current_update)



    def predictAndUpdate(self, true_label, svm_scores): #@Override
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence.
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): here, the label predicted by the multinomial only.
         * ``prediction_scores`` (*list*): final combined svm+prediction score for each label
        """
        #Prediction by exploiting the weights
        predicted_label, prediction_scores = Multinomial_Forecaster.getPrediction(self, true_label)
        prediction_scores = np.ravel(prediction_scores / np.sum(prediction_scores))

        #Update scores and sliding window
        current_update = np.zeros_like(self.weights)
        current_update[true_label] += 1

        self.weights += current_update
        self.update_past(current_update)

        return predicted_label, prediction_scores * svm_scores




class Dynamic_Self_Guided_Unsupervised_Multinomial_Forecaster(Dynamic_Multinomial_Forecaster):
    """Dynamic Unsupervised Multinomial Forecaster.
    """


    def __init__(self, k, update=1.0, epsilon=0.5):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.5.
        """
        Dynamic_Multinomial_Forecaster.__init__(self, k, update, epsilon)


    def reinit(self):
        """
        Reinitialize the forecaster
        """
        Dynamic_Multinomial_Forecaster.reinit(self)



    def predictAndUpdate(self, true_label, svm_scores):
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence. (Will only be used to compute accuracies not for the update).
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): the label predicted by the combined pretrained+adaptation.
         * ``prediction_scores`` (*list*): final adaptation classifier (pretrained+adaptation score for each label).

        """

        #Prediction by exploiting the weights + svm scores
        _, forecaster_scores = Dynamic_Multinomial_Forecaster.getPrediction(self, true_label)
        forecaster_scores = np.ravel(forecaster_scores / np.sum(forecaster_scores))

        #Combine with classifier probabilities
        combined_scores = svm_scores * forecaster_scores
        predicted_label = random.choice(np.argwhere(combined_scores == np.amax(combined_scores))[:, 0])

        #Update scores and sliding windows
        total = np.sum(combined_scores)
        current_update = combined_scores / total

        self.weights += current_update
        self.update_past(current_update)

        return predicted_label, combined_scores








class Dynamic_Reinforced_Multinomial_Forecaster(Dynamic_Multinomial_Forecaster):
    """Dynamic Reinforced Multinomial Forecaster.
    """


    def __init__(self, k, update=1.0, epsilon=0.5):
        """
        Object initialization.

        Args:
         * ``k`` (*int*): number of labels that could appear in the sequences.
         * ``update`` (*float, optional*): update parameter. Defaults to 1.
         * ``epsilon`` (*float, optional*): initial weights' value. Defaults to 0.5.
        """
        Dynamic_Multinomial_Forecaster.__init__(self, k, update, epsilon)



    def reinit(self):
        """
        Reinitialize the forecaster
        """
        Dynamic_Multinomial_Forecaster.reinit(self)



    def predictAndUpdate(self,true_label, svm_scores): #@Override
        """
        Predicts the next label and updates the weights.

        Args:
         * ``true_label`` (*int*): the next label in the sequence.
         * ``svm_scores`` (*list*): SVM output for the corresponding query.

        Returns:
         * ``predicted_label`` (*int*): the label predicted by the combined svm+prediction classifier.
         * ``prediction_scores`` (*list*): final combined svm+prediction score for each label
        """

        #Prediction by exploiting the weights + svm scores
        _, forecaster_scores = Multinomial_Forecaster.getPrediction(self, true_label)
        forecaster_scores = np.ravel(forecaster_scores / np.sum(forecaster_scores))

        #Combine with SVM-Platt probabilistic scores
        combined_scores = svm_scores * forecaster_scores
        predicted_label = random.choice(np.argwhere(combined_scores == np.amax(combined_scores))[:, 0])

        #Update scores and sliding window
        if predicted_label == true_label:
            current_update = np.zeros_like(self.weights)
            current_update[predicted_label] += self.update
        else:
            current_update = np.zeros_like(self.weights) + 1.0 / (self.k - 1)
            current_update[predicted_label] = 0

        self.weights += current_update
        self.update_past(current_update)

        return predicted_label, combined_scores
