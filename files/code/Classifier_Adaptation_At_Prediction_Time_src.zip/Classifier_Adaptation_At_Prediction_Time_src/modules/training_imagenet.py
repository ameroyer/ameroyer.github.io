#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **training_imagenet.py**

functions to train a SVM  classifier using JSGD.
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"

import sys
import numpy as np
import ConfigParser as cfg
from accuracy_measures import *



def import_test_data(all_syns, D, FEATUREPATTERN, num_classes, n, d):
    """
    This function imports the image features and test labels from the pathes given in the configuration file.

    Args:
     * ``all_syns`` (*dict*): contains the wordnetId of the leaf labels.
     * ``D`` (*dict*): maps a wordnetId to the corresponding imagenetId.
     * ``FEATUREPATTERN`` (*str*): string format of the path to features. (FEATUREPATTERN%synset = features for synset)
     * ``num_classes`` (*int*): number of classes in this task.
     * ``n`` (*int*): number of features in the whole database.
     * ``d`` (*int*): features' dimension.

    Returns:
     * ``rawData`` (*ndarray*): matrix containing the features. (nxd array).
     * ``rawLabels`` (*list*): ground truth labels for the features.
     * ``n`` (*int*): the number of features that were imported.

    """
    # Randomize data while reading it
    perm = np.random.permutation(n)
    rawData = np.empty((n,d), np.float32)
    rawLabels = np.zeros(n, np.int32)
    np.random.seed(0)
    n = 0
    for i, syn in enumerate(all_syns):
        print "Synset %d/%d..." % (i+1, len(all_syns)),
        X = np.reshape(np.fromfile( FEATUREPATTERN % syn, dtype=np.float32),(-1,d))
        m = X.shape[0]
        print syn,m
        rawData[perm[n:n+m],:] = X
        rawLabels[perm[n:n+m]] = D[syn]*np.ones(m, np.int32)
        n += m

    # If we use a subset of classes, discard empty entries
    if len(all_syns) != num_classes:
        mask = (rawLabels > 0)
        rawData = np.ascontiguousarray(rawData[mask])
        rawLabels = np.ascontiguousarray(rawLabels[mask])
    del X

    # convert to 0-based indexing
    rawLabels -= rawLabels.min()
    return rawData, rawLabels, n




def jsgd_training(trnData, trnLabels, valData, valLabels, params, eval_freq, n_epoch):
    """
    This function trains k OVR SVM classifiers using jsgd.  (note that the parameters should be writte in ``configuration.ini``).

    Args:
     * ``trnData`` (*ndarray*): matrix containing the training features. (nxd array).
     * ``trLabels`` (*list*): ground truth labels for the training features.
     * ``valData`` (*ndarray*): matrix containing the features used for cross-validation. (nxd array).
     * ``valLabels`` (*list*): ground truth labels for the cross-validation features.

    Returns:
     * ``W`` (*ndarray*): weights of each classifier (kxd array).
     * ``params`` (*struct*):  parameters used for the training.

    """
    from jsgd import *
    #Input features x(n,d); output weights w(nClass, d+1)
    W, stats = jsgd_train(trnData, trnLabels,
                valid = valData,
                valid_labels = valLabels,
                eval_freq = eval_freq,
                n_epoch = n_epoch,
                verbose = 2,
                want_stats = True,
                n_thread = 1,
                accuracy_function = compute_accuracy,
                **params)

    print "Final top-5 accuracy during jsgd training = ", stats.valid_accuracies[-1]
    return W
