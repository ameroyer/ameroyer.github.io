#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **plotting.py**

Various functions linked to plotting.
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"

import matplotlib
matplotlib.use('Agg', warn=False) #NoDisplay
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.colors as colors

import sys
import time

import numpy as np
from utils import init_folder



def init_figure(title, xlabel, ylabel):
    """
    Default Maplotlib figure look and feel
    """
    fig = plt.figure()
    fig.set_facecolor('white')
    fig.suptitle(title + ' - all methods', fontsize=14, fontweight='bold')
    ax = fig.add_subplot(1,1,1, axisbg = 'GhostWhite')
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    return fig, ax


def perplexities_plot(filename, output_pdf, title, line = -1, xlim = 0):
    fig, ax = init_figure(title, 'Time', 'Perplexity')
    fig.subplots_adjust(top=0.85)

    label_names = np.genfromtxt(filename, dtype = 'str', usecols = 0)
    results = np.genfromtxt(filename, dtype = 'float')[:, 1:]

    plt.plot(results[line, :], marker='+', color='r', linestyle='-', label = label_names[line])
    if xlim:
        plt.xlim([0,xlim])
    plt.ylim([3.5,7.0])
    ax = plt.gca()
    handles, labels = ax.get_legend_handles_labels()
    lgd = plt.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5,-0.1))
    pp = PdfPages(output_pdf)
    fig.savefig(pp, dpi = 10, format = 'pdf',  bbox_extra_artists=(lgd,), bbox_inches='tight')
    pp.close()



def param_plot(filename, output_pdf, title, xlabel, ylabel, line = -1):
    """
    A simple function for comparing accuracies on a plot.

    Args:
     * ``filename`` (*str*): path to the matrix containing the accuracies (note that the first column should contain labels, the first line contains parameters values to plot against, and the last column contains SVM scores). see ``Imagenet_parameter_analysis`` for more details.
     * ``output_pdf`` (*str*): path to the file the figure will be plotted in.
     * ``title`` (*str*): title of the final figure.
     * ``xlabel`` (*str*): title of the x-axis.
     * ``ylabel`` (*str*): title of the y-axis.
     * ``line`` (*int, optional*): indicates which data sequence's scores will be plotted,  and compared to the basic SVM scores. Defaults to -1 (last line : mean scores).

    """
    fig, ax = init_figure(title, xlabel, ylabel)
    fig.subplots_adjust(top=0.85)


    label_names = np.genfromtxt(filename, dtype = 'str', usecols = 0, skip_header = 1)
    matrix = np.genfromtxt(filename, dtype = 'float')[:, 1:]
    results = matrix[1:, :-1]
    params = matrix[0, :-1]
    svm = matrix[1:, -1]

    plt.plot(params, results[line, :], marker='+', color='r', linestyle='-', label = label_names[line])
    plt.axhline(y = svm[line], xmin = min(params), xmax = max(params), color = 'b', label = 'SVM ' + label_names[line])

    ax = plt.gca()
    handles, labels = ax.get_legend_handles_labels()
    lgd = plt.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5,-0.1))
    pp = PdfPages(output_pdf)
    fig.savefig(pp, dpi = 10, format = 'pdf',  bbox_extra_artists=(lgd,), bbox_inches='tight')
    pp.close()






def result_plot(filename, output_pdf, title, ylabel, lines = None):
    """
    A simple function for comparing accuracies on a plot. Compared to param_plots, only the form of the input changes.

    Args:
     * ``filename`` (*str*): path to the matrix containing the accuracies (note that the first column should contain labels, the first line contains parameters values to plot against. Finally, the last line is supposed to contain SVM scores). See ``Imagenet_parameter_analysis`` for more details.
     * ``output_pdf`` (*str*): path to the file the figure will be plotted in.
     * ``title`` (*str*): title of the final figure.
     * ``xlabel`` (*str*): title of the x-axis.
     * ``ylabel`` (*str*): title of the y-axis.
     * ``line`` (*int, optional*): indicates which data sequence's scores will be plotted,  and compared to the basic SVM scores. Defaults to None (plot accuracies for all methods).

    """
    from itertools import cycle
    styles = cycle(['black', 'DimGray', 'Crimson', 'SkyBlue', 'SlateBlue', 'ForestGreen', 'DarkOrange', 'Orchid'])
    label_names = np.genfromtxt(filename, dtype = 'str', usecols = 0, skip_header = 1)
    matrix = np.genfromtxt(filename, dtype = 'float')[:, 1:]
    results = matrix[1:, :]
    params = range(0, len(matrix[0, :]))
    if lines is not None: #If line != None, select lines
        results = results[lines, :]
        label_names = label_names[lines]


    #Plot whisker boxes
    if results.shape[1] > 1:
        fig, ax = init_figure(title, 'Method', ylabel)
        #results = 1 - results
        fig.subplots_adjust(top=0.85, bottom = 0.4)
        ax.boxplot(results.T)
        plt.ylim([0,1])
        plt.xticks(range(1, len(label_names)+1), label_names, rotation=60)
        pp = PdfPages(output_pdf.split('.')[0] + '_Whisker.pdf')
        fig.savefig(pp, dpi = 10, format = 'pdf')
        pp.close()
    else:
        print 'Only one sequence; No whisker boxes plotted'

    #Plot results on ax
    fig, ax = init_figure(title, 'Sequence', ylabel)
    fig.subplots_adjust(top=0.85)
    for i, l in enumerate(results):
        c = color=styles.next()
        ax.plot(params, l, marker='+', color = c, linestyle='-', label = label_names[i])
    ax = plt.gca()
    handles, labels = ax.get_legend_handles_labels()
    lgd = plt.legend(handles, labels, loc='upper center', bbox_to_anchor=(0.5,-0.1))
    pp = PdfPages(output_pdf)
    fig.savefig(pp, dpi = 10, format = 'pdf',  bbox_extra_artists=(lgd,), bbox_inches='tight')
    pp.close()
