#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **generate_task_sequence_MDS.py**

Generates a labels sequence from a Multi Dimensional Scaling plot.
"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import os
import sys
import numpy as np
from random import choice, random
from data_representation import mds_mapping


def random_walk_MDS(n, datapoints, k, tree_struct, height=0, filename=None, hypernims=None, lambd=0):
    """
    This function returns a sequence of labels computed with a random walk on a MDS 2D representation of the data.

    Args:
     * ``n`` (*int*): sequence's length.
     * ``datapoints`` (*ndarray*): MDS 2D projection of the labels.
     * ``k`` (*int*): number of neighbours for the kNN search. (Including current point).
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``height`` (*int, optional*): If given, and filename and hypernims are not None, then the name and ID of the ancester of this height for each label will be output with the sequence.
     * ``filename`` (*str, optional*): path to the file the sequence will be written in (Imagenet ID). Defaults to None.
     * ``hypernims`` (*list, optional*): list mapping a leaf-label to one of its ancestors for a given height. These relations will be used to display the ancestors classes. Defaults to None.
     * ``lambd`` (*float*): probability of making a random jump.

    Returns:
     * ``label_list`` (*list*): a sequence of n labels.

    """
    from scipy.spatial import cKDTree # For kNN search
    kdtree = cKDTree(datapoints)
    label_list = [0] * n
    if filename is not None:
        f = open(filename, 'w')

    r = choice(xrange(len(datapoints))) # Randomly choose starting point
    for i in xrange(n):
        [x, y] = datapoints[r]
        classID = r + 1
        class_name = tree_struct[classID].synset[0]
        if height != 0 and hypernims is not None:
            ancestorID = hypernims[classID][0]
            ancestor_name = tree_struct[ancestorID].synset[0]
            s = "%d | %s | %d | %d | %s | %d \n" %(classID, class_name, 0, ancestorID, ancestor_name, height)
        else:
            s = "%d | %s \n" %(classID, class_name)
        if filename is not None:
            f.write(s)

        label_list[i] = classID - 1

        jump = random()
        if jump < lambd:
            r = choice(xrange(len(datapoints)))
        else:
            dist, index = kdtree.query([x, y], k)
            r = choice(index)


    if filename is not None:
        print 'Output saved in', filename
        f.close()

    return label_list



def get_sequence_MDS(n, k, dists, tree_struct, imported_coordinates=None, height=None, hypernims=None, lambd=0, output_walk=None, output_coord_file=None):
    """
    This function builds the MDS projection from a distance matrix (if it hadn't been done), and then returns a sequence of labels computed with a random walk on a MDS 2D representation of the data.

    Args:
     * ``n`` (*int*): sequence's length.
     * ``k`` (*int*): parameter for the kNN search.
     * ``dists`` (*ndarray*): distance matrix for the projection.
     * ``tree_struct`` (*dict*): contains the nodes of the hierarchy tree (see ``extract_data.Node``).
     * ``imported_coordinates`` (*str, optional*): path to the file containing the precomputed projected datapoint coordinates. Defaults to None.
     * ``height`` (*int, optional*): See random_walk_grid.
     * ``hypernims`` (*list, optional*) : See random_walk_grid.
     * ``lambd`` (*float*): probability of making a random jump.
     * ``output_walk`` (*str, optional*): path to the file the sequence will be written in. Defaults to None.
     * ``output_coord_file`` (*str, optional*): path to the file the coordinates will be written in. Defaults to None.

    Returns:
     * ``label_list`` (*list*): a sequence of n labels.
    """

    if imported_coordinates is None or not os.path.isfile(imported_coordinates):
        coords = mds_mapping(dists, output_coord_file)

    else:
        print "Imported Coordinates from ", imported_coordinates
        coords = np.loadtxt(imported_coordinates)

    return random_walk_MDS(n, coords, k, tree_struct, height=height, hypernims=hypernims, lambd=lambd, filename=output_walk)
