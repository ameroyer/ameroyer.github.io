#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

"""
**Imagenet_train.py**

For training a multi-class SVM classifier with jsgd + Platt Parameters.

python Imagenet_train.py -y [1]

**Args**:
  |[1] : Database (2010 or 2012). Defaults to 2010.

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


if __name__ == '__main__':
    import sys
    import os
    import ConfigParser as cfg                         # 'configparser' for Python 3+
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    sys.path.append(config.get('Lib', 'jsgd'))
    import numpy as np
    import pickle
    from modules.accuracy_measures import scores, confusion_matrix
    from modules.training_imagenet import *
    from modules.svm_to_prob import use_platt_scaling
    from modules.utils import Tee, init_folder
    import time
    base_name = time.strftime("%Y-%m-%d_%H-%M")
    import argparse


    #----------------------------------------- Main Parameters + Configuration
    parser = argparse.ArgumentParser(description='Training the Imagenet database using JSGD.')
    parser.add_argument("year", type=int, default=2010, help="Database (2010 or 2012)")
    args = parser.parse_args()
    YEAR = args.year


    #-------- Configuration
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    section = str(YEAR)
    max_class = 1000
    num_classes = config.getint(section, 'n_classes')
    n, d = config.getint(section, 'n'), config.getint(section, 'd')
    folder = init_folder(os.path.join(config.get('Folders', 'output'), 'ImageNet', 'ILSVRC%d'%YEAR))

    FEATUREPATTERN = config.get(section, 'featurePattern', raw = True)
    validationSet = np.fromfile(config.get(section, 'validationSet'), dtype = np.float32).reshape(-1,d)
    validationLabels =  np.loadtxt(config.get(section, 'validationLabels'), dtype = np.int32).T - 1


    #------- Output files
    output_training = os.path.join(folder, 'Trained_SVM_Platt.pkl')
    output_params_txt = os.path.join(folder, 'Platt_params.txt')
    output_confusion = os.path.join(folder, 'Confusion_matrix.txt')
    print "Function's output will be saved in folder", folder

    #--------- print Redirecting Output
    output_log = os.path.join(folder, "output_%s.log" % base_name)
    f = open(output_log, 'w')
    original = sys.stdout
    withfile = Tee(sys.stdout, f)
    sys.stdout = withfile


    #--------------------------------------------------- Preprocess Synsets
    from extract_data import Node, extract_data
    arrangeddata = extract_data(YEAR)
    D = arrangeddata['wordID_to_ImageID']
    all_syns = arrangeddata['all_wordID']




    #====================================================================================#
    #-------------------------------- JSGD TRAINING -------------------------------------#
    #====================================================================================#

    print "Training with JSGD"
    print "-> Reading data: "
    sys.stdout = original
    rawData, rawLabels, num_feature = import_test_data(all_syns, D, FEATUREPATTERN, num_classes, n, d)
    sys.stdout = withfile
    print "-> done."
    print "Labels comprised between %d and %d" %(rawLabels.min(),rawLabels.max())


    if num_feature > 1000000:
        n_train = num_feature - 50000 #Fixed 50K validation data set. Used for Platt training.
    else:
        n_train = int(num_feature*0.95) # 5% validation set

    trnData = np.ascontiguousarray(rawData[:n_train])
    trnLabels = np.ascontiguousarray(rawLabels[:n_train])
    valData = np.ascontiguousarray(rawData[n_train:])
    valLabels = np.ascontiguousarray(rawLabels[n_train:])

    # Parameters
    config.read('configuration.ini')
    section = 'training'
    params = {'_lambda': config.getfloat(section, 'reglambda'),
              'beta': config.getint(section, 'beta'),
              'eta0': config.getfloat(section, 'eta0'),
              'fine_tune_bias': config.getint(section, 'fine_tune_bias'),
              'stop_valid_threshold': config.getfloat(section, 'stop_valid_threshold'),
              'fixed_eta': config.getint(section, 'fixed_eta')}
    n_epoch = config.getint(section, 'n_epoch')
    eval_freq = config.getint(section, 'eval_freq')

    # Training
    W = jsgd_training(trnData, trnLabels, valData, valLabels, params, eval_freq, n_epoch)
    print 'Training parameters', params
    print valData.shape
    print W.shape


    # Compute Confusion Matrix
    print "Computing confusion Matrix"
    all_scores, found_labels = scores(valData, W)
    confusion = confusion_matrix(found_labels, valLabels, num_classes)
    np.savetxt(output_confusion, confusion, fmt = '%.8f')

    x = {}
    x['weights'] = W
    x['year'] = YEAR



    #====================================================================================#
    #------------------------- Learning Platt Parameters --------------------------------#
    #====================================================================================#
    print "Starting Platt Scaling"
    #Save Platt parameters in pkl file + txt file
    x['platt_params'] = use_platt_scaling(all_scores.shape[0], all_scores,  valLabels, outputfile = output_params_txt)


    #Save final output (classifiers weights and platt parameters)
    print "Writing Output in", output_training
    with open(output_training, "wb") as of:
        pickle.dump(x, of)

    f.close()
