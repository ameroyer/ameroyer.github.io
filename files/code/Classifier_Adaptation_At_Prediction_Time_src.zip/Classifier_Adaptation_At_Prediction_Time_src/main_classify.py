#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************

""" **main_classifiy.py**

Runs experiments with the different adaptation scenario with the chosen options.

Default Call::

    python main_classify.py -y [1] -s [2] -n [3] -l [4] -j [5] -c [6]

**Args**:

* [1] (*int*): database (2010 or 2012).
* [2] (*str*): method for sequence generation (TXT, KS, or MDS for realistic label sequences; RND for random).
* [3] (*int*): number of sequences. Defaults to 5.
* [4] (*int*): generated sequence length. Defaults to 1500.
* [4] (*float*): probability of a random jump for MDS and KS. Defaults to 0.
* [6] (*str*): classifier to use. (``ccv`` or ``jsgd``). Defaults to ``ccv``.
"""


__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"




if __name__ == '__main__':
    import os
    import sys
    import pickle
    import time
    import argparse
    from random import shuffle
    import ConfigParser as cfg                         # 'configparser' for Python 3+
    import numpy as np
    from generate_task_sequence import generate_seq
    from extract_data import Node, extract_data
    from modules.import_sequence import *
    from modules.init_forecasters import *
    from modules.utils import init_folder, Tee
    from modules.accuracy_measures import compute_accuracy
    from modules.plotting import result_plot, perplexities_plot
    base_name = time.strftime("%Y-%m-%d_%H-%M")


# -------------------------- INIT PARAMETERS AND PATHES

    # ----------Main Parameters
    parser = argparse.ArgumentParser(description='Classifier adaptation on ImageNet based on a pre-trained SVM or CCV classifier.')
    parser.add_argument("-y", "--year", dest="year", default=2010, type=int, help="Database (2010 or 2012). Defaults to 2010.")
    parser.add_argument("-s", "--set", dest="set", default="TXT", type=str, help="Label Sequence database (TXT, KS, MDS or RND). Defaults to TXT.")
    parser.add_argument("-n", "--ntot", dest="ntot", default=5, type=int, help="Number of sequences to use. Defaults to 5.")
    parser.add_argument("-l", "--length", dest="seql", default=1500, type=int, help="Length of the sequences. Defaults to 1500. (Unused for TXT option)")
    parser.add_argument("-j", "--jump", dest="lambd", default=0, type=float, help="Random jump probability for the KS and MDS databases")
    parser.add_argument("-c", "--classifier", dest="classi", default="ccv", help="Pre-trained classifier (jsgd or ccv). Defauts to ccv.")
    parser.add_argument("-v", "--verbose", help="verbose output.", action="store_true")

    args = parser.parse_args()
    year = args.year
    using_set = args.set
    n_total = args.ntot
    seq_length = args.seql
    classifier = args.classi
    verbose = args.verbose
    lambd = args.lambd

    if year not in [2010, 2012]:
        print >> sys.stderr, "Only 2010 and 2012 options supportes"
        raise SystemExit

    if using_set not in ['KS', 'MDS', 'TXT', 'RND']:
        print >> sys.stderr, "Only KS, MDS, TXT and RND options supported"
        raise SystemExit

    # --------- Set configuration Pathes (training features + validation data)
    config = cfg.ConfigParser()
    main_dir = os.path.dirname(os.path.realpath(__file__))
    config.read(os.path.join(main_dir, 'configuration.ini'))

    section = str(year)
    folder = init_folder(os.path.join(config.get('Folders', 'output'), 'ImageNet', 'ILSVRC%d' % year, '%s_%s%s' % (using_set, classifier, '_%s'%lambd if using_set in ['KS', 'MDS'] else '')))
    num_classes = config.getint(section, 'n_classes')
    adaptation_schemes = load_forecasters(config)

    # Path to pre-trained classifier scores
    precomputed_jsgd = config.get('classify', 'precomputed_scores', raw=True) % year
    precomputed_ccv = config.get('classify', 'precomputed_ccv', raw=True) % year
    true_labels = np.loadtxt(config.get(section, 'validationLabels'), dtype=np.int32).T - 1  # ground-truth labels of the validation database with 1-shift in order to begin at index 0

    # Load synsets information
    arrangeddata = extract_data(year)
    tree_struct = arrangeddata['tree']
    del arrangeddata

    # Log file
    logf = open(os.path.join(folder, "output_%s.log" % base_name), "w")
    sys.stdout = Tee(sys.stdout, logf)


    # ============================================================== LOAD PRE-TRAINED CLASSIFIER f
    # CCV
    if classifier == 'ccv':
        print 'Loading precomputed CCV scores'
        svm_scores = None
        try:
            with open(precomputed_ccv, 'r') as pkl_file:
                x = pickle.load(pkl_file)
                probs_scores = x['probs']
                del x
        except (OSError, KeyError):
            print 'File not found or Missing "probs" entry in dictionnary', precomputed_ccv
            print 'Exiting'
            raise SystemExit

    # JSGD
    elif classifier == 'jsgd':
        print 'Loading precomputed SVM-PLATT classifier scores'
        try:
            with open(precomputed_jsgd, 'r') as pkl_file:
                x = pickle.load(pkl_file)
                svm_scores = x['svm']
                probs_scores = x['probs']
        except (OSError, KeyError):
            print 'File not found or Missing "svm" or "prob" entry in dictionnary', precomputed_jsgd
            print 'Exiting'
            raise SystemExit


# ============================================================== INIT LABEL SEQUENCES
    print 'Importing %s sequence(s)' % using_set

    # Import pre-computed TXT sequences
    if using_set == 'TXT':
        txt_path = config.get('classify', 'path_to_txt', raw=True) % year
        flist = [x for x in os.listdir(txt_path) if x.endswith('.txt') and os.stat(os.path.join(txt_path, x)).st_size != 0]
        shuffle(flist)
        flist = flist[:n_total]
        seq_test = [(name.split('.')[0], import_seq_features(os.path.join(txt_path, name), tree_struct, true_labels)) for name in flist]
        max_seq_length = max([len(s) for (_, (_, s)) in seq_test])

    # Generate Random MDS or KS sequence
    elif using_set == 'MDS' or using_set == 'KS':
        k = config.getint('classify', 'mds_knn')
        imported = config.get('classify', 'path_to_mds' if using_set == 'MDS' else 'path_to_ks', raw=True) % year
        seq_test = [('%s_seq%d' % (using_set, i), import_seq_features_aux(generate_seq(imported, using_set, seq_length, tree_struct, k=k, lambd=lambd, verbose=verbose), true_labels)) for i in xrange(n_total)]
        max_seq_length = seq_length

    # RND (random sequences)
    elif using_set == 'RND':
        seq_test = []
        indices = range(probs_scores.shape[1]) if classifier == 'ccv' else range(svm_scores.shape[1])
        c = list(zip(indices, true_labels))
        for j in xrange(n_total):
            shuffle(c)
            seq_test.append(('Random_data_%d' % j, zip(*(c[:seq_length]))))
        max_seq_length = seq_length

    # Check
    if len(seq_test) == 0:
        print 'No input sequences, Exiting'
        raise SystemExit

    # ============================================================== START CLASSIFICATION

    # ----------------------------------------Define which combined algorithms to use

    if svm_scores is not None:
        methods = ['Base(SVM)', 'Base(Probs)']
    else:
        methods = ['Base(Probs)']
    forecasters, loaded_forecasters = init_forecaster_module(num_classes, adaptation_schemes)
    methods.extend(loaded_forecasters)
    print 'Using adaptation methods :', methods
    sequences = ['_']  # Accumulator for the names of evaluated sequences

    # Results (top1 error, top5 error, perplexity)
    errors1 = np.zeros((len(methods), len(seq_test)))
    errors5 = np.zeros((len(methods), len(seq_test)))
    perplexities = np.zeros((len(methods), len(seq_test)))

    # Cumulative perplexity for Online Adaptation + Dynamic Adaptation for comparison
    if verbose:
        if 'Multinomial' in adaptation_schemes:
            mult_perplexities = np.zeros((len(seq_test), max_seq_length))
        if 'Dynamic_Multinomial' in adaptation_schemes:
            Umult_perplexities = np.zeros((len(seq_test), max_seq_length))


    # ================================== Browse each label sequence and compute evaluation measures
    for ns, (name, (indices, labels)) in enumerate(seq_test):
        #name: sequence name, indices: samples in the sequence, labels: true labels for the samples
        sequences.append(name)
        print 'Sequence %s : %d / %d. length %d' % (name, ns + 1, n_total, len(labels))

        # 1. Compute scores for pre-trained classifiers alone
        start_index = 0
        # ----------- Basic SVM accuracy
        if svm_scores is not None:
            errors1[0, ns] = 1.0 - compute_accuracy(svm_scores[:, indices].T, labels, topk=1, verbose=verbose)
            errors5[0, ns] = 1.0 - compute_accuracy(svm_scores[:, indices].T, labels, topk=5, verbose=verbose)
            perplexities[0, ns] = -1  # Not a probability, no interpretation
            start_index += 1


        # ----------- Basic SVM accuracy after Platt scaling or CCV probabilistic scores
        basic_probs = probs_scores[:, indices]
        if 'Base(Probs)' in methods:
            errors1[start_index, ns] = 1.0 - compute_accuracy(basic_probs.T, labels, topk=1, verbose=verbose)
            errors5[start_index, ns] = 1.0 - compute_accuracy(basic_probs.T, labels, topk=5, verbose=verbose)
            seq_prob = [np.log(basic_probs[l, j]) if basic_probs[l,j] > 0 else 0. for j, l in enumerate(labels)]
            perplexities[start_index, ns] = - np.sum(seq_prob) / len(labels)
            start_index += 1


        # 2. Compute scores for the Adaptation methods
        reinit_forecasters(forecasters)
        adapt_arrays = init_array_scores(basic_probs, forecasters)

        # Prediction
        for i, label in enumerate(labels):
            for j, mat in enumerate(adapt_arrays):
                f = forecasters[methods[j + start_index]]
                _, adaptation_scores = f.predictAndUpdate(label, mat[:, i])
                mat[:, i] = adaptation_scores
                perplexities[j + start_index, ns] -= np.log(mat[label, i] / np.sum(mat[:, i])) if mat[label,i] > 0 else 0.


        # Compute error for the adaptation classifiers
        for j, mat in enumerate(adapt_arrays):
            errors1[start_index + j, ns] = 1.0 - compute_accuracy(mat.T, labels, topk=1, verbose=verbose)
            errors5[start_index + j, ns] = 1.0 - compute_accuracy(mat.T, labels, topk=5, verbose=verbose)
            perplexities[start_index + j, ns] /= len(labels)


        # Cumulative perplexities for multinomial + unlearning multinomial
        if verbose:
            if 'Multinomial' in methods:
                cump = forecasters['Multinomial'].getCumulativePerplexities()
                mult_perplexities[ns, :] = np.append(cump, np.ones(max_seq_length - len(cump)) * cump[-1]) #pad with last value if different sequence lengthes (TXT)

            if 'Dynamic_Multinomial' in methods:
                cump2 = forecasters['Dynamic_Multinomial'].getCumulativePerplexities()
                Umult_perplexities[ns, :] = np.append(cump2, np.ones(max_seq_length - len(cump2)) * cump2[-1])



# ================================ Print Final Results
    print '\n--------Final Results :', using_set, n_total, 'x', seq_length
    print '->Mean Top-1 errors'
    for i, line in enumerate(errors1):
        print "_ %s : %.5f +- %.3f" % (methods[i], np.mean(line), np.std(line))

    print '\n\n->Mean Top-5 errors'
    for i, line in enumerate(errors5):
        print "_ %s : %.5f +- %.3f" % (methods[i], np.mean(line), np.std(line))

    # Wilcoxon if verbose mode
    if verbose:
        from scipy.stats import wilcoxon
        print '\n\n->Wilcoxon for top-1 errors'
        for j, line in enumerate(errors1):
            if j == 0:
                continue
            _, p = wilcoxon(errors1[0, :], line)
            print "_ %s : %e" % (methods[j], p)

        print '\n\n->Wilcoxon for top-5 errors'
        for j, line in enumerate(errors5):
            if j == 0:
                continue
            _, p = wilcoxon(errors5[0, :], line)
            print "_ %s : %e" % (methods[j], p)

    # Perplexities if verbose mode
    if verbose:
        print '\n->Mean Perplexities'
        for i, line in enumerate(perplexities):
            print methods[i], 'Mean perplexity:', np.mean(line), '+-', np.std(line)


    # -------------------------- Write Output (files + plots)
    # Add label headers to errors arrays before output
    errors1 = np.row_stack((sequences, np.column_stack((methods, errors1))))
    errors5 = np.row_stack((sequences, np.column_stack((methods, errors5))))
    perplexities = np.row_stack((sequences, np.column_stack((methods, perplexities))))

    # Base output name
    if using_set == 'TXT':
        output = '%s_%d_%d_%s.txt' % (using_set, n_total, year, base_name)
    else:
        output = '%s_%dx%d_%d_%s.txt' % (using_set, n_total, seq_length, year, base_name)

    # Save error rates
    print '\n\n Saving and Plotting Output'
    err1_output = os.path.join(folder, 'Err1_%s' % output)
    with open(err1_output, "w") as text_file:
        np.savetxt(text_file, errors1, fmt='%s')
    result_plot(err1_output, '%s.pdf' % (err1_output.rsplit('.', 1)[0]), '%s_Means' % using_set, 'Err-1', lines=None)

    err5_output = os.path.join(folder, 'Err5_%s' % output)
    with open(err5_output, "w") as text_file:
        np.savetxt(text_file, errors5, fmt='%s')
    result_plot(err5_output, '%s.pdf' % (err5_output.rsplit('.', 1)[0]), '%s_Means' % using_set, 'Err-5', lines=None)


    # In verbosity mode, output perplexities
    if verbose:
        # Perplexities
        perp_output = os.path.join(folder, 'Perp_%s' % output)
        with open(perp_output, "w") as text_file:
            np.savetxt(text_file, perplexities, fmt='%s')
        result_plot(perp_output, '%s.pdf' % (perp_output.rsplit('.', 1)[0]), '%s_Means' % using_set, 'Perplexity', lines=None)


        # Cumulative perplexities for online adapt and dynamic adapt
        if 'Multinomial' in adaptation_schemes:
            mult_perplexities = np.column_stack((sequences[1:] + ['Mean'], np.row_stack((mult_perplexities, np.mean(mult_perplexities, axis=0)))))
            cumulperp_output = os.path.join(folder, 'MultCumulPerp_%s' % output)
            with open(cumulperp_output, "w") as text_file:
                np.savetxt(text_file, mult_perplexities, fmt='%s')
            perplexities_plot(cumulperp_output, '%s.pdf' % (cumulperp_output.rsplit('.', 1)[0]), 'Multinomial Prediction perplexities', line=-1)


        if 'Dynamic_Multinomial' in adaptation_schemes:
            Umult_perplexities = np.column_stack((sequences[1:] + ['Mean'], np.row_stack((Umult_perplexities, np.mean(Umult_perplexities, axis=0)))))
            cumulperp2_output = os.path.join(folder, 'DynamicMultCumulPerp_%s' % output)
            with open(cumulperp2_output, "w") as text_file:
                np.savetxt(text_file, Umult_perplexities, fmt='%s')
            perplexities_plot(cumulperp2_output, '%s.pdf' % (cumulperp2_output.rsplit('.', 1)[0]), 'Dynamic Multinomial Prediction perplexities', line=-1)

    # Close log file
    logf.close()
