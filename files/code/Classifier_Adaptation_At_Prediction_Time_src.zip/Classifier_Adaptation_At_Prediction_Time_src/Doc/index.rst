Contents:
========

.. toctree::
   :maxdepth: 2

   Running and Evaluating adaption classifiers <RST/main_classify>
   Demo Script <RST/demo_classify>
   Data Preprocessing <RST/extract_data>
   Training base classifiers on ImageNet (jsgd) <RST/Imagenet_train>
   2D Projection of the Hierarchy <RST/hierarchy_to_map>
   Generating realistic label sequences <RST/generate_task_sequence>
   Generating image sequences <RST/sequence_to_images>
   Auxiliary function <RST/modules>


.. include:: ../README



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
