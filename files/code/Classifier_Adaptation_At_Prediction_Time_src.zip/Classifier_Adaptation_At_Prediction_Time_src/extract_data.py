#!/usr/bin/python
# -*- coding: utf-8 -*-

#***************************** License *************************************
#
#    Copyright (C) 2014  Royer Amélie
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#****************************************************************************


""" **extract_data.py**

This module is used to preprocess additional information on the dataset and Imagenet hierarchy and store them in an internal representation.
Default Call::

    python extract_data.py [year] [options]


**Args**:

* [year] (*int*) : ILSVRC year (2010 or 2012).
* [options] (*str, optional*) :
    * -h, --help: display help.
    * -tree: additionally outputs the hierarchy tree in a dot/pdf file.


**********************************
Processing the ILSVRC data format
**********************************

"""

__author__= "Amélie Royer"
__date__ = "2014"
__email__= "amelie.royer@ist.ac.at"


import sys
import os
import pickle
import numpy as np
from modules.utils import init_folder
from modules.compute_imagenet_hierarchy import get_misclassification_costs
import ConfigParser as cfg                         # 'configparser' for Python 3+


#=========================================================================================#
#================================== Tree Structure =======================================#
#=========================================================================================#
# Each node will then be stored in a dict which linked an ImageNetID to a Node instance
class Node():
    """
    .. _node-label:

        Node.
        This class represents a node in the ILSVRC hierarchy tree.
    """


    def __init__(self, imagenetId, wordnetId, children, leaf_children, parent, synset, leaf_min_heights, max_height):
        """
        Object initialization.

        Args:
         * ``imagenetId`` (*int*): imagenetId of the node (in range [|1, 1000|]).
         * ``wordnetId`` (*int*): wordnetId of the node.
         * ``children`` (*list*): imagenetIds of this node's children.
         * ``leaf_children`` (*list*): imagenetIds of this node's children that are located in the leaves. Note that if this node is a leaf, leaf_children will contains itself, and only.
         * ``parent`` (*list*): imagenetIds of this node's parents.
         * ``synset`` (*list*): node's words description.
         * ``leaf_min_heigts`` (*dict*): this dict maps the imagenetid of one of the node's leaf children to the minimum height between the node and its child.
         * ``max_height`` (*int*): maximum length of a path going from the node to a leaf.

        """
        self.imagenetId = imagenetId
        self.wordnetId = wordnetId
        self.children = children
        self.childrenNumber = len(children)
        self.leaf_children = leaf_children
        self.leaf_min_heights = leaf_min_heights
        self.min_height = min(leaf_min_heights.values())
        self.max_height = max_height
        self.parent = parent
        self.synset = synset
        self.isLeaf = (imagenetId <= 1000)
        self.isRoot = (imagenetId == 1001)







#=========================================================================================#
#======================== Finding Father to Children Relations ===========================#
#=========================================================================================#

def find_nth_parent(child, parents_table, n):
    """
    Returns the ancestor of height ``n`` of a node. If none exists, then it returns its highest ancestor in the hierarchy.

    Args:
     * ``child`` (*int*): the imagenetId of the node we are currently visiting.
     * ``parents_table`` (*dict*): mapping from an imagenetId to the imagenetId of the node's parent(s).
     * ``n`` (*int*): the maximum height we are exploring.

    Returns:
     * ``found`` (*bool*): indicates wether height n was reached or not.
     * ``child`` (*int*): the imagenetId of the retrieved parent.
    """
    if n <= 0:
        return (True, child)
    else:
        try:
            for possible_parent in parents_table[child]:
                (done, c) = find_nth_parent(possible_parent, parents_table, n-1)
                if done:
                    return (True, c)
            #If nothing higher in the hierarchy, returns the last found parent
            return (False, c)
        except KeyError: #No higher parent
            return (False, child)



def find_leaf_children(origin, current_node, Id, current_height, output, output_heights):
    """
    Returns all the descendants of a node that are also leaves, and builds an array containing the distances between ancestors and their children.

    Args:
     * ``origin`` (*int*): the imagenetId of the node whose children we are looking for.
     * ``current_node`` (*int*): the imagenetId of the node we are currently visiting.
     * ``Id`` (*dict*): original ILSVRC metafile object.
     * ``current_height`` (*int*): the height we are currently visiting.
     * ``output`` (*dict*): mapping from an imagenetId to the imagenetId of the node's leaf children.
     * ``output_heights`` (*ndarray*): contains the minimal length of path from a node to another node in the same subtree.
    """

    if current_node[0][5][0].size == 0:
        index = current_node[0][0][0][0]
        output.append(index)
    else:
        for c in current_node[0][5][0]:
            new_height = min(current_height, output_heights[origin - 1, c -1])
            output_heights[origin - 1, c -1] = new_height
            output_heights[c - 1, origin -1] = new_height
            find_leaf_children(origin, Id[c - 1], Id, current_height + 1, output, output_heights)



def findLCA ( tree_struct, distances_matrix, root = 1001, num_classes = 1000):
    """
    Finds the lowest common ancestor for any pairs of nodes (for the ILSVRC hierarchy only; for operations on the full hierarchy, see ``compute_imagenet_hierarchy.py``).

    Args:
     * ``tree_struct`` (*dict*): maps an imagenetId to the corresponding :ref:`Node <node-label>` object.
     * ``distances_matrix`` (*ndarray*): the maximum height we are exploring.
     * ``root`` (*int, optional*): the imagenetId of the root of the hierarchy. Defaults to 1001 "entity".
     * ``num_classes`` (*int, optional*): number of leaf nodes in the hierarchy. Defaults to 1000.


    Returns:
     * ``lca_mat`` (*ndarray*): matrix of the LCA for the leaf nodes, such that lca_matrix[x,y] = the common ancestor of imagenetid (x+1) and (y+1) which is the closest of (x+1).
    """
    #Initialization
    lca_matrix = np.zeros((num_classes, num_classes)) - 1
    for i in xrange(num_classes):
        lca_matrix[i, i] = i

    #Sort node by increasing height
    nodes = sorted(tree_struct.values(), key = lambda x : x.max_height)
    #For each node, browse its leave children and update the matrix
    for node in nodes:
        label = node.imagenetId
        leaves = node.leaf_children

        for i, labelA in enumerate(leaves):
            for j in xrange(i+1, len(leaves)):
                labelB = leaves[j]
                current_lca = lca_matrix[labelA - 1, labelB - 1]
                if current_lca == -1:
                    lca_matrix[labelA - 1, labelB - 1] = label - 1
                    lca_matrix[labelB - 1, labelA - 1] = label - 1
                else:
                    if distances_matrix[label -1, labelA - 1] < distances_matrix[current_lca, labelA - 1]:
                        lca_matrix[labelA - 1, labelB - 1] = label - 1
                    if distances_matrix[label -1, labelB - 1] < distances_matrix[current_lca, labelB - 1]:
                        lca_matrix[labelB - 1, labelA - 1] = label - 1

    return lca_matrix





#=========================================================================================#
#============================ Main preprocessing Function  ===============================#
#=========================================================================================#

def preprocess_synsets(METAFILE, hierarchy_xml, num_classes, max_class, heights, filename=None):
    """
    Extracts information from the hierarchy and stores them in a pickle file.

    Args:
     * ``metafile`` (*str*): path to the .mat file from the ILSVRC challenge.
     * ``hierarchy_xml`` (*str*): path to the .xml file containing the full ImageNet hierarchy (needed for ILSVRC2012).
     * ``num_classes`` (*int*): number of classes (leaf nodes) in the dataset.
     * ``max_class`` (*int*): maximum ImageNet Id of the classes that will be used as labels for the task.
     * ``heights`` (*list*): list of all the heights we compute hypernims relations for.
     * ``filename`` (*str, optional*): path to the pickle file in which the resulting object will be stored. Defaults to None.


    Returns:
     * ``arrangeddata`` (*dict*): a dict containing various informations about the hierarchy and having the following keys :
        * ``'tree'`` (*dict*): dict mapping an ImageNet id (*int*) to the corresponding :ref:`Node <node-label>`.
        * ``'cost_matrix'`` (*ndarray*): contains the 1000x1000 matrix of the distances (height of lowest common ancestor) between the leaf nodes.
        * ``'wordID_to_ImageID'`` (*dict*): is a dict mapping a wordnetId to the corresponding ImagenetId.
        * ``'all_wordID'`` (*list*): contains the list of all wordnetId appearing in the data file, sorted in alphabetical order.
        * ``'synsets_to_ids'`` (*dict*): dict mapping a word to:
            - a tuple (*'', ImageNetId*), if it is a one-word synset
            - a tuple (*(position in the synset, whole sysnet), ImageNetId*), if the word is part of a multi-words synset.
        * ``'computed_heights'`` (*list*): contains the list of all heights for which the data was preprocesssed.
        * ``'heights'`` (*dict*): dictionnary which maps an height (*int*) to a tuple (hypernims, hyponinms, number of ancestors) for this height.

    """

    from scipy.io import loadmat, savemat
    meta = loadmat(METAFILE)
    M = meta['synsets']

    D = {}
    Id = {}
    synsets = {}
    parents_table = {}
    leaf_children_table = {}
    synsets_to_ids = {}
    tree_struct = {}
    arrangeddata = {}

    total_classes = len(M)
    print "The dataset contains %d nodes" %total_classes

    #-------------First Loop
    print 'Computing Parent relations and synset to labels relations'
    for m in M:
        index = m[0][0][0][0]
        # WordnetId to ImagenetId
        D[m[0][1][0]] = index

        # Get parents relations
        for c in m[0][5][0]:
            try:
                parents_table[c].append(index)
            except KeyError:
                parents_table[c] = [index]

        #G et synsets
        words = [w.lower().strip() for w in m[0][2][0].split(',')]
        synsets[m[0][0][0][0]] = words
        # Associate a word to ImagenetId(s) that contain it for generate_task_sequence_TXT.py
        for s in words:
            units = s.split()
            if len(units) > 1:
                for i, u in enumerate(units):
                    toappend = ((i, units), index)
                    try:
                        synsets_to_ids[u].append(toappend)
                    except KeyError:
                        synsets_to_ids[u] = [toappend]

            else:
                toappend = ('', index)
                try:
                    synsets_to_ids[s].append(toappend)
                except KeyError:
                    synsets_to_ids[s] = [toappend]
    all_wordId = [key for key, val in D.iteritems() if val <= max_class]
    all_wordId.sort()


    #--------------Second loop, builds the tree structure
    auxH = np.zeros((len(M), len(M))) + 20
    for i in xrange(len(M)):
        auxH[i, i] = 0
    print 'Building the tree structure'
    for m in M:
        index = m[0][0][0][0]
        #Get children in the leaf
        aux = []
        find_leaf_children(index, m, M, 1, aux, auxH)
        leaf_children = list(set(aux))
        leaf_min_heights = {k : auxH[k - 1, index - 1] for k in leaf_children}
        try:
            parent = parents_table[index]
        except KeyError:
            parent = -1
        tree_struct[index] = Node(index, m[0][1][0], m[0][5][0], leaf_children, parent, synsets[index], leaf_min_heights, m['wordnet_height'][0][0][0])
    del synsets


    #--------------- Third loop for lca and distances matrix
    print 'Compute LCA and distance matrix if needed'
    lca_mat = findLCA( tree_struct, auxH)
    arrangeddata['lca_matrix'] = lca_mat
    try:
        arrangeddata['cost_matrix'] = meta['cost_matrix'] #Doesn't exist for 2012
    except KeyError:
        print "Computing cost matrix"
        subset = sorted(D.items(), key=lambda (k, v): v[1])
        map(lambda (k,v): k, subset)
        arrangeddata['cost_matrix'] = get_misclassification_costs(subset, hierarchy_xml)


    #------------ Final loop, precompute ancestor relations for all heights
    # Note : in case of several parents, only consider the first one
    print 'Computing hypernims and hyponims relations for each given height'
    arrangeddata['heights'] = {}
    for height in heights:
        hypernims = [[] for j in xrange(num_classes + 1)]                    #hypernims[synset] = [ancestor's ImageNetId, ancestor's index among all the ancestors of the given height]
        hyponims = [[] for j in xrange(total_classes+1)]                     #hyponims[synset] = [ImageNetIds of the leaf children for this given height]
        is_ancestor = [-1]*len(D)                                            #is_ancestor[synset] = index as an ancestor among all the ancestors of the given height
        i = -1  #Current number of retrieved ancestors
        for label in all_wordId:
            iD = D[label]
            (done, ancestor) = find_nth_parent(iD, parents_table, height)
            if ancestor != None:
                hyponims[ancestor].append(iD)
                index = is_ancestor[ancestor-1]
                if index >= 0:
                    hypernims[iD] = [ancestor, index]
                else:
                    i += 1
                    is_ancestor[ancestor-1] = i
                    hypernims[iD] = [ancestor, i]
        print "Height %d : %d ancestor synsets found" %(height, i+1)
        arrangeddata['heights'][height] = (hypernims, hyponims, i+1)


    #Storing
    arrangeddata['wordID_to_ImageID'] = D
    arrangeddata['all_wordID'] = all_wordId
    arrangeddata['synsets_to_ids'] = synsets_to_ids
    arrangeddata['computed_heights'] = heights
    arrangeddata['tree'] = tree_struct

    #Writing in file if provided
    if filename is not None:
        print "Saving preprocessed data file to", filename
        print "Contains : ", arrangeddata.keys()
        init_folder(os.path.dirname(os.path.abspath(filename)))
        with open(filename, "wb") as f:
            pickle.dump(arrangeddata, f)

    return arrangeddata






def init_data(metafile, savedatafile, hierarchyfile, heights=range(16), num_classes=1000, max_class=1000):
    """
    Wrapper for preprocess_synsets. This function computes the hierarchy from the given metafile iff it doens't already exist (in savedatafile).

    Args:
     * ``metafile`` (*str*): path to .mat from the ILSVRC challenge.
     * ``savedatafile`` (*str*): path to the .pkl file for loading/saving the extracted information on the hiearrchy.
     * ``hierarchyfile`` (*str*): path to the .xml file containing the full ImageNet hierarchy. May be needed if the .mat file does not contain hierarchical cost information.
     * ``heights`` (*int, optional*): maximum height to explore for hypernims/hyponims relations. Defaults to 15.
     * ``num_classes`` (*int, optional*) : number of classes (leaf nodes) in the dataset. Defaults to 1000.
     * ``max_class`` (*int, optional*): maximum Id of the class that will be used as label for the task. Defaults to 1000.


    Returns:
     * ``arrangeddata`` (*dict*): the result of preprocess_Synsets.
    """
    if not os.path.isfile(savedatafile):
        print 'Preprocessing Synsets'
        arrangeddata = preprocess_synsets(metafile, hierarchyfile,  num_classes, max_class, heights, filename = savedatafile)
    else:
        print 'Data loaded from', savedatafile
        with open(savedatafile, 'rb') as pkl_file:
            arrangeddata = pickle.load(pkl_file)
    return arrangeddata





def extract_data(year, heights=range(16), num_classes=1000, max_class=1000, tree=False):
    """
    Second wrapper for preprocess_synsets. This function computes the hierarchy in the same way as init_data but directly uses the pathes  found in the ``root_folder/configuration.ini`` file.

    Args:
     * ``year`` (*int*): ILSVRC Database year.
     * ``heights`` (*int, optional*): maximum height to explore for hypernims/hyponims relations. Defaults to 15.
     * ``num_classes`` (*int, optional*) : number of classes (leaf nodes) in the dataset. Defaults to 1000.
     * ``max_class`` (*int, optional*): maximum Id of the class that will be used as label for the task. Defaults to 1000.
     * ``tree`` (*bool, optional*): if True, the function will also output a tree representation of the hierarchy in a .dot/.pdf file. Defaults to False.


    Returns:
     * ``arrangeddata`` (*dict*): the result of preprocess_Synsets.
    """
    config = cfg.ConfigParser()
    config.read('configuration.ini')
    section = str(year)
    savedatafile = config.get(section, 'preprocessedMetafile')
    if savedatafile == '':
       savedatafile = 'Data/arrangeddata' + str(YEAR) + '.pkl'
       init_folder('Data/')

    metafile = config.get(section, 'metafile')
    hierarchyfile = config.get('ImageNet', 'hierarchy')
    arrangeddata = init_data(metafile, savedatafile, hierarchyfile, heights, num_classes, max_class)

    if tree:
        from modules.data_representation import generate_dot_file
        tree_struct = arrangeddata['tree']
        output = savedatafile.rsplit('.', 1)[0] + '_tree.dot'
        generate_dot_file(tree_struct, output)

    return arrangeddata





#=========================================================== Main
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='For extracting various information about the hierarchy from the orignal ImageNet metafile. The output path should can be changed from configuration.ini.')
    parser.add_argument("year", type = int, help="Database (2010 or 2012)")
    parser.add_argument("-tree", action="store_true", dest = "tree", help="When this option is passed, the script additionally generates the hierarchy in a dot and pdf file. If not, the script only extracts the data information.")
    args = parser.parse_args()

    _ = extract_data(args.year, tree = args.tree)
